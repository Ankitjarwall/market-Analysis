"""
Daily FII / DII participant-wise data via nsepython.

Runs once per trading day around 7:30 PM IST (after NSE publishes the report).

Tables written: fii_dii_daily
Derived fields:
  fii_streak        - consecutive same-direction days in FII cash net
  fii_options_bias  - from call_oi vs put_oi
  client_bias       - derived from retail (clients) participant row
"""
import json
import asyncio
from datetime import datetime, timezone, timedelta, date

import db

IST = timezone(timedelta(hours=5, minutes=30))

try:
    import nsepython
    HAS_NSE = True
except Exception as e:
    print(f"[fii_dii] nsepython import failed: {e}")
    HAS_NSE = False

import requests as req_lib
from bs4 import BeautifulSoup


# ── Helpers ─────────────────────────────────────────────────────────────────
def _safe_num(x) -> float:
    try:
        return float(str(x).replace(",", "").replace("₹", "").strip())
    except Exception:
        return 0.0


def _bias_from_oi(call_oi: float, put_oi: float) -> str:
    if call_oi + put_oi == 0:
        return "NEUTRAL"
    ratio = put_oi / max(1, call_oi)
    if ratio > 1.2:  return "BULLISH"  # more puts written → bullish
    if ratio < 0.83: return "BEARISH"
    return "NEUTRAL"


# ── Main fetch ──────────────────────────────────────────────────────────────
def _fetch_nse_data() -> dict:
    """Blocking call to nsepython. Returns dict with normalized fields."""
    if not HAS_NSE:
        return {}

    result = {
        "fii_net_today": 0.0,
        "fii_futures":   0.0,
        "fii_call_oi":   0,
        "fii_put_oi":    0,
        "dii_net_today": 0.0,
        "client_call_oi":0,
        "client_put_oi": 0,
        "raw":           {},
    }
    try:
        # ---- Cash market FII/DII ---------------------------------------
        cash = nsepython.nse_fiidii()
        # Returns list of dicts usually: FII, DII, etc.
        if isinstance(cash, list):
            for row in cash:
                cat = str(row.get("category", "")).upper()
                net = _safe_num(row.get("netValue") or row.get("net_value") or 0)
                if "FII" in cat or "FPI" in cat:
                    result["fii_net_today"] = net
                elif "DII" in cat:
                    result["dii_net_today"] = net
        result["raw"]["cash"] = cash
    except Exception as e:
        print(f"[fii_dii] cash fetch err: {e}")

    try:
        # ---- F&O participant-wise (FII futures, FII options OI) --------
        fno = nsepython.nse_fnoparticipant()
        result["raw"]["fno"] = fno

        if isinstance(fno, dict):
            # The API returns a dict keyed by participant name
            fii = fno.get("FII", {}) if isinstance(fno.get("FII"), dict) else {}
            cli = fno.get("Client", {}) if isinstance(fno.get("Client"), dict) else {}

            # Common shapes — try a few paths
            result["fii_futures"] = _safe_num(
                fii.get("futures_net") or
                fii.get("Future Index Net") or
                fii.get("index_futures_net") or 0
            )
            result["fii_call_oi"] = int(_safe_num(
                fii.get("call_oi") or fii.get("Option Index Call OI") or 0
            ))
            result["fii_put_oi"]  = int(_safe_num(
                fii.get("put_oi") or fii.get("Option Index Put OI") or 0
            ))
            result["client_call_oi"] = int(_safe_num(
                cli.get("call_oi") or cli.get("Option Index Call OI") or 0
            ))
            result["client_put_oi"]  = int(_safe_num(
                cli.get("put_oi") or cli.get("Option Index Put OI") or 0
            ))
    except Exception as e:
        print(f"[fii_dii] fno fetch err: {e}")

    return result


def _fetch_moneycontrol_fallback() -> dict:
    """Fallback: scrape FII/DII cash data from moneycontrol."""
    result = {
        "fii_net_today": 0.0, "fii_futures": 0.0,
        "fii_call_oi": 0, "fii_put_oi": 0,
        "dii_net_today": 0.0,
        "client_call_oi": 0, "client_put_oi": 0,
        "raw": {"source": "moneycontrol_fallback"},
    }
    try:
        url = "https://www.moneycontrol.com/stocks/marketstats/fii_dii_activity/data.json"
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
        r = req_lib.get(url, headers=headers, timeout=15)
        js = r.json()
        result["raw"]["mc_response"] = js

        # moneycontrol usually returns {data: [{category, buyValue, sellValue, netValue}, ...]}
        if isinstance(js, dict) and "data" in js:
            for row in js["data"]:
                cat = str(row.get("category", "")).upper()
                net = _safe_num(row.get("netValue", 0))
                if "FII" in cat or "FPI" in cat:
                    result["fii_net_today"] = net
                elif "DII" in cat:
                    result["dii_net_today"] = net
    except Exception as e:
        print(f"[fii_dii] moneycontrol fallback err: {e}")

    return result


async def fetch_and_store():
    """Try nsepython first, fallback to moneycontrol if it fails."""
    loop = asyncio.get_event_loop()

    data = None
    # Source 1: nsepython
    if HAS_NSE:
        try:
            data = await loop.run_in_executor(None, _fetch_nse_data)
            if data and data.get("fii_net_today", 0) != 0:
                print("[fii_dii] source: nsepython")
            else:
                data = None
        except Exception as e:
            print(f"[fii_dii] nsepython failed: {e}")
            data = None

    # Source 2: moneycontrol fallback
    if not data:
        try:
            data = await loop.run_in_executor(None, _fetch_moneycontrol_fallback)
            if data and data.get("fii_net_today", 0) != 0:
                print("[fii_dii] source: moneycontrol fallback")
            else:
                print("[fii_dii] both sources returned empty data")
                return
        except Exception as e:
            print(f"[fii_dii] moneycontrol fallback failed: {e}")
            return

    if not data:
        return

    # Determine today's trading date (IST)
    today = datetime.now(IST).date()

    # ── Streak calculation ────────────────────────────────────────────────
    prev = await db.fetchrow(
        "SELECT fii_net_today, fii_streak FROM fii_dii_daily "
        "ORDER BY date DESC LIMIT 1"
    )
    cur_net = data["fii_net_today"]
    streak = 1
    if prev:
        prev_net = float(prev["fii_net_today"] or 0)
        prev_streak = int(prev["fii_streak"] or 1)
        if (prev_net > 0) == (cur_net > 0) and cur_net != 0:
            streak = prev_streak + 1
        else:
            streak = 1 if cur_net != 0 else 0

    # ── Options bias ──────────────────────────────────────────────────────
    fii_bias    = _bias_from_oi(data["fii_call_oi"], data["fii_put_oi"])
    client_bias = _bias_from_oi(data["client_call_oi"], data["client_put_oi"])

    # ── Upsert ────────────────────────────────────────────────────────────
    await db.execute(
        """INSERT INTO fii_dii_daily
           (date, fii_net_today, fii_streak, fii_futures,
            fii_call_oi, fii_put_oi, fii_options_bias,
            dii_net_today, client_bias, raw, fetched_at)
           VALUES ($1,$2,$3,$4, $5,$6,$7, $8,$9, $10::jsonb, NOW())
           ON CONFLICT (date) DO UPDATE SET
               fii_net_today   = EXCLUDED.fii_net_today,
               fii_streak      = EXCLUDED.fii_streak,
               fii_futures     = EXCLUDED.fii_futures,
               fii_call_oi     = EXCLUDED.fii_call_oi,
               fii_put_oi      = EXCLUDED.fii_put_oi,
               fii_options_bias= EXCLUDED.fii_options_bias,
               dii_net_today   = EXCLUDED.dii_net_today,
               client_bias     = EXCLUDED.client_bias,
               raw             = EXCLUDED.raw,
               fetched_at      = NOW()""",
        today, data["fii_net_today"], streak, data["fii_futures"],
        data["fii_call_oi"], data["fii_put_oi"], fii_bias,
        data["dii_net_today"], client_bias,
        json.dumps(data["raw"], default=str),
    )
    print(f"[fii_dii] stored {today}  FII={data['fii_net_today']:+.1f}Cr  streak={streak}  bias={fii_bias}")
