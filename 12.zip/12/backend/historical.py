"""
Historical candle backfill.

Phases:
  Phase 1 (default recommended scope)
    1m    -> last 60 days
    5m    -> last 1 year
    15m   -> last 3 years
    1d    -> last 10 years
  Phase 2 (extended, after phase 1 complete)
    1m    -> last 3 years
    5m    -> last 3 years   (same as phase 1, skipped)
    15m   -> last 3 years   (same as phase 1, skipped)
    1d    -> last 15 years

Retry policy: if a chunk hits Angel One's rate limit, mark the row as
'pending' with next_retry_at = now + 3 hours. The scheduler re-invokes
run_pending() every 30 minutes.

Progress is printed to the terminal and stored in `backfill_status.progress_pct`.
"""
import asyncio
import math
import time as _time
from datetime import datetime, timedelta, timezone
from dataclasses import dataclass
import pandas as pd
import requests as req_lib

import db
from indicators import compute_indicators, INDICATOR_COLS

# ── Configuration ──────────────────────────────────────────────────────────
IST = timezone(timedelta(hours=5, minutes=30))
RETRY_WAIT  = timedelta(hours=3)

ANGEL_HIST_URL = "https://apiconnect.angelone.in/rest/secure/angelbroking/historical/v1/getCandleData"

# Angel One interval names
INTERVAL_MAP = {
    "1m":  "ONE_MINUTE",
    "5m":  "FIVE_MINUTE",
    "15m": "FIFTEEN_MINUTE",
    "1d":  "ONE_DAY",
}

# Table name per timeframe
TABLE_MAP = {
    "1m":  "candles_1m",
    "5m":  "candles_5m",
    "15m": "candles_15m",
    "1d":  "candles_1d",
}

# Max days Angel One allows per single call per timeframe
MAX_DAYS_PER_CALL = {
    "1m":  30,     # 1-minute: up to ~30 days per call
    "5m":  90,     # 5-minute: up to ~90 days per call
    "15m": 180,    # 15-minute: up to ~180 days per call
    "1d":  2000,   # 1-day: effectively whole range per call
}

# Phase definitions (per symbol)
PHASES = {
    1: {
        "1m":  60,     # days
        "5m":  365,
        "15m": 365 * 3,
        "1d":  365 * 10,
    },
    2: {
        "1m":  365 * 3,
        "5m":  365 * 3,   # same as phase 1 — skipped
        "15m": 365 * 3,   # same as phase 1 — skipped
        "1d":  365 * 15,
    },
}


# ── Global handle set by main.py at startup ────────────────────────────────
_headers_fn = None     # returns dict of Angel One REST headers
_indices_cfg = None    # dict of symbol -> {token, exchangeType, ...}


def register(headers_fn, indices_cfg):
    global _headers_fn, _indices_cfg
    _headers_fn = headers_fn
    _indices_cfg = indices_cfg


# ── Public entry points ────────────────────────────────────────────────────
async def ensure_jobs():
    """Populate backfill_status with one row per (symbol, timeframe, phase)."""
    if _indices_cfg is None:
        return
    now = datetime.now(timezone.utc)
    for symbol, cfg in _indices_cfg.items():
        for phase, tf_days in PHASES.items():
            for tf, days in tf_days.items():
                # Phase 2 only extends what phase 1 didn't already cover
                if phase == 2 and days <= PHASES[1][tf]:
                    continue
                target_from = now - timedelta(days=days)
                target_to   = now
                await db.execute(
                    """INSERT INTO backfill_status
                       (symbol, asset_type, timeframe, phase, target_from, target_to, status)
                       VALUES ($1, 'index', $2, $3, $4, $5, 'pending')
                       ON CONFLICT (symbol, asset_type, timeframe, phase) DO NOTHING""",
                    symbol, tf, phase, target_from, target_to
                )
    print("[backfill] jobs ensured")


async def run_pending():
    """Pick up all 'pending' jobs whose next_retry_at has elapsed and run them."""
    now = datetime.now(timezone.utc)
    rows = await db.fetch(
        """SELECT * FROM backfill_status
            WHERE status IN ('pending','running')
              AND (next_retry_at IS NULL OR next_retry_at <= $1)
              AND asset_type = 'index'
            ORDER BY phase ASC, timeframe ASC""",
        now
    )
    if not rows:
        return
    print(f"[backfill] {len(rows)} pending job(s) — starting")
    for row in rows:
        await _run_one_index(dict(row))


async def run_options_backfill():
    """Backfill 1-min candles for ATM ± 10 strikes of the current expiry, last 45 days.
       Called once the index backfill has made progress."""
    # This is a placeholder — actual implementation requires knowing current option
    # tokens. We call it after the option chain has loaded at least once, so the
    # scripmaster data is available.
    print("[backfill] options backfill — TODO (runs after option chain is loaded)")


# ── Index backfill worker ──────────────────────────────────────────────────
async def _run_one_index(job: dict):
    symbol = job["symbol"]
    tf     = job["timeframe"]
    phase  = job["phase"]
    cfg    = _indices_cfg.get(symbol)
    if not cfg:
        return

    chunk_days = MAX_DAYS_PER_CALL[tf]
    total_days = (job["target_to"] - job["target_from"]).days
    cursor     = job["last_fetched_to"] or job["target_from"]
    target_to  = job["target_to"]

    await db.execute(
        "UPDATE backfill_status SET status='running', updated_at=NOW() WHERE id=$1",
        job["id"]
    )

    try:
        while cursor < target_to:
            chunk_end = min(cursor + timedelta(days=chunk_days), target_to)
            candles   = await asyncio.to_thread(
                _fetch_chunk, cfg, tf, cursor, chunk_end
            )
            if candles is None:
                # Rate limit → schedule retry
                retry_at = datetime.now(timezone.utc) + RETRY_WAIT
                await db.execute(
                    """UPDATE backfill_status
                         SET status='pending', retry_count=retry_count+1,
                             next_retry_at=$1, error='rate-limited', updated_at=NOW()
                       WHERE id=$2""",
                    retry_at, job["id"]
                )
                print(f"[backfill] rate-limited on {symbol} {tf} phase{phase} — retry at {retry_at:%H:%M IST}")
                return

            if candles:
                await _persist_index_candles(symbol, cfg["token"], tf, candles)

            cursor = chunk_end
            pct = min(100.0, (cursor - job["target_from"]).days * 100.0 / max(1, total_days))
            await db.execute(
                """UPDATE backfill_status
                     SET last_fetched_to=$1, progress_pct=$2, updated_at=NOW()
                   WHERE id=$3""",
                cursor, pct, job["id"]
            )
            print(f"[backfill] {symbol:10s} {tf:4s} phase{phase} → {pct:5.1f}%  "
                  f"({cursor:%Y-%m-%d})")
            await asyncio.sleep(0.3)   # gentle spacing

        # Done
        await db.execute(
            """UPDATE backfill_status SET status='complete', progress_pct=100,
                    updated_at=NOW() WHERE id=$1""",
            job["id"]
        )
        print(f"[backfill] ✓ {symbol} {tf} phase{phase} complete")
    except Exception as e:
        await db.execute(
            """UPDATE backfill_status SET status='pending', error=$1,
                    next_retry_at=$2, updated_at=NOW() WHERE id=$3""",
            str(e)[:500], datetime.now(timezone.utc) + RETRY_WAIT, job["id"]
        )
        print(f"[backfill] error {symbol} {tf}: {e}  — retry in 3h")


def _fetch_chunk(cfg: dict, tf: str, start: datetime, end: datetime):
    """Call Angel One historical API. Returns:
         list of [ts, o, h, l, c, v]
         None if rate-limited
         []   on non-fatal empty response
    """
    if _headers_fn is None:
        return []
    # Angel One wants dates in "YYYY-MM-DD HH:MM" IST
    start_ist = start.astimezone(IST)
    end_ist   = end.astimezone(IST)
    payload = {
        "exchange":    "NSE" if cfg["exchangeType"] == 1 else "BSE",
        "symboltoken": cfg["token"],
        "interval":    INTERVAL_MAP[tf],
        "fromdate":    start_ist.strftime("%Y-%m-%d %H:%M"),
        "todate":      end_ist.strftime("%Y-%m-%d %H:%M"),
    }
    try:
        r = req_lib.post(ANGEL_HIST_URL, json=payload, headers=_headers_fn(), timeout=30)
        js = r.json()
    except Exception as e:
        print(f"[backfill] fetch err: {e}")
        return None

    msg = (js.get("message") or "").lower() if isinstance(js, dict) else ""
    if "rate" in msg or "exceed" in msg or r.status_code == 429:
        return None
    if not js.get("status"):
        # Could be 'Invalid token', 'No data', etc — treat as empty
        return []
    return js.get("data") or []


async def _persist_index_candles(symbol: str, token: str, tf: str, candles: list):
    """Take raw Angel One candles, compute indicators, insert into candles_Xm."""
    if not candles:
        return
    # Angel One row format: [ts_iso, open, high, low, close, volume]
    try:
        df = pd.DataFrame(candles, columns=["time", "open", "high", "low", "close", "volume"])
        df["time"] = pd.to_datetime(df["time"], utc=True)
        df = df.set_index("time").sort_index()
        for c in ("open", "high", "low", "close", "volume"):
            df[c] = pd.to_numeric(df[c], errors="coerce")

        df = compute_indicators(df)

        table = TABLE_MAP[tf]
        rows = []
        for ts, r in df.iterrows():
            vals = []
            for col in INDICATOR_COLS:
                v = r.get(col)
                if pd.isna(v):
                    vals.append(None)
                elif col in ("obv", "supertrend_dir"):
                    vals.append(int(v))
                else:
                    vals.append(float(v))
            rows.append((
                ts.to_pydatetime(), symbol, token,
                float(r["open"]) if not pd.isna(r["open"]) else None,
                float(r["high"]) if not pd.isna(r["high"]) else None,
                float(r["low"])  if not pd.isna(r["low"])  else None,
                float(r["close"]) if not pd.isna(r["close"]) else None,
                int(r["volume"]) if not pd.isna(r["volume"]) else 0,
                *vals,
            ))

        if not rows:
            return
        # Use executemany with ON CONFLICT DO NOTHING
        await db.executemany(
            f"""INSERT INTO {table}
                (time, symbol, token, open, high, low, close, volume,
                 rsi, macd, macd_signal, macd_hist,
                 ema_9, ema_21, ema_50, vwap, adx, atr,
                 bb_upper, bb_middle, bb_lower,
                 supertrend, supertrend_dir, obv)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,
                        $9,$10,$11,$12,
                        $13,$14,$15,$16,$17,$18,
                        $19,$20,$21,
                        $22,$23,$24)
                ON CONFLICT (time, symbol) DO NOTHING""",
            rows,
        )
    except Exception as e:
        print(f"[backfill] persist err: {e}")


# ── Startup entrypoint (called from main.py) ───────────────────────────────
async def start_background():
    """Ensure jobs exist, then run them in a loop until all complete.
       Runs in its own task so it doesn't block startup."""
    try:
        await ensure_jobs()
        await run_pending()
    except Exception as e:
        print(f"[backfill] background err: {e}")
