"""
Async Postgres / TimescaleDB pool.

Usage:
    import db
    await db.init()                          # on startup
    async with db.pool.acquire() as conn:    # anywhere
        rows = await conn.fetch("SELECT 1")
"""
import os
import asyncio
import asyncpg
from pathlib import Path

pool: asyncpg.Pool | None = None


async def init(max_retries: int = 30):
    """Create the pool; retry a few times since the DB may still be booting."""
    global pool
    if pool is not None:
        return pool

    host     = os.getenv("DB_HOST",     "db")
    port     = int(os.getenv("DB_PORT", "5432"))
    user     = os.getenv("DB_USER",     "market")
    password = os.getenv("DB_PASSWORD", "market_pw_2026")
    database = os.getenv("DB_NAME",     "market")

    for attempt in range(1, max_retries + 1):
        try:
            pool = await asyncpg.create_pool(
                host=host, port=port, user=user, password=password,
                database=database, min_size=2, max_size=10,
                command_timeout=60,
            )
            print(f"[db] Connected to {host}:{port}/{database}")
            return pool
        except Exception as e:
            print(f"[db] connect attempt {attempt}/{max_retries} failed: {e}")
            await asyncio.sleep(2)

    raise RuntimeError("Could not connect to the database after retries")


async def close():
    global pool
    if pool is not None:
        await pool.close()
        pool = None


# ── Convenience helpers ─────────────────────────────────────────────────────
async def fetch(query: str, *args):
    async with pool.acquire() as conn:
        return await conn.fetch(query, *args)


async def fetchrow(query: str, *args):
    async with pool.acquire() as conn:
        return await conn.fetchrow(query, *args)


async def fetchval(query: str, *args):
    async with pool.acquire() as conn:
        return await conn.fetchval(query, *args)


async def execute(query: str, *args):
    async with pool.acquire() as conn:
        return await conn.execute(query, *args)


async def executemany(query: str, args_list):
    async with pool.acquire() as conn:
        return await conn.executemany(query, args_list)


async def copy_records(table: str, records, columns: list[str]):
    """Fast bulk insert via COPY."""
    if not records:
        return 0
    async with pool.acquire() as conn:
        return await conn.copy_records_to_table(table, records=records, columns=columns)


# ── System state K/V ────────────────────────────────────────────────────────
async def state_get(key: str, default=None):
    row = await fetchrow("SELECT value FROM system_state WHERE key = $1", key)
    return row["value"] if row else default


async def state_set(key: str, value):
    import json
    await execute(
        """INSERT INTO system_state (key, value, updated)
           VALUES ($1, $2::jsonb, NOW())
           ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated = NOW()""",
        key, json.dumps(value)
    )
