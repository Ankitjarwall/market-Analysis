-- ═══════════════════════════════════════════════════════════════════════════
--  Market Data Schema — TimescaleDB
--  Runs automatically on first DB init (docker-entrypoint-initdb.d)
-- ═══════════════════════════════════════════════════════════════════════════

CREATE EXTENSION IF NOT EXISTS timescaledb;

-- ── 1. raw_ticks ──────────────────────────────────────────────────────────
--   Every index tick, kept 7 days (auto-pruned)
CREATE TABLE IF NOT EXISTS raw_ticks (
    time        TIMESTAMPTZ     NOT NULL,
    symbol      TEXT            NOT NULL,
    token       TEXT            NOT NULL,
    ltp         NUMERIC(12,2),
    open        NUMERIC(12,2),
    high        NUMERIC(12,2),
    low         NUMERIC(12,2),
    close       NUMERIC(12,2),
    volume      BIGINT,
    exchange_ts TIMESTAMPTZ
);
SELECT create_hypertable('raw_ticks', 'time', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_raw_ticks_symbol_time ON raw_ticks (symbol, time DESC);
SELECT add_retention_policy('raw_ticks', INTERVAL '7 days', if_not_exists => TRUE);

-- ── 2. Index candles (1m, 5m, 15m, 1d) ────────────────────────────────────
--   Every candle is self-contained: OHLCV + all indicators.
--   This is the PRIMARY training source for the AI.
DO $$
DECLARE
    tf TEXT;
BEGIN
    FOREACH tf IN ARRAY ARRAY['candles_1m','candles_5m','candles_15m','candles_1d']
    LOOP
        EXECUTE format('
            CREATE TABLE IF NOT EXISTS %I (
                time          TIMESTAMPTZ     NOT NULL,
                symbol        TEXT            NOT NULL,
                token         TEXT            NOT NULL,
                open          NUMERIC(12,2),
                high          NUMERIC(12,2),
                low           NUMERIC(12,2),
                close         NUMERIC(12,2),
                volume        BIGINT,
                rsi           NUMERIC(8,4),
                macd          NUMERIC(12,4),
                macd_signal   NUMERIC(12,4),
                macd_hist     NUMERIC(12,4),
                ema_9         NUMERIC(12,4),
                ema_21        NUMERIC(12,4),
                ema_50        NUMERIC(12,4),
                vwap          NUMERIC(12,4),
                adx           NUMERIC(8,4),
                atr           NUMERIC(12,4),
                bb_upper      NUMERIC(12,4),
                bb_middle     NUMERIC(12,4),
                bb_lower      NUMERIC(12,4),
                supertrend    NUMERIC(12,4),
                supertrend_dir SMALLINT,
                obv           BIGINT,
                PRIMARY KEY (time, symbol)
            );', tf);
        EXECUTE format('SELECT create_hypertable(''%I'', ''time'', if_not_exists => TRUE);', tf);
        EXECUTE format('CREATE INDEX IF NOT EXISTS idx_%I_symbol_time ON %I (symbol, time DESC);', tf, tf);
    END LOOP;
END $$;

-- ── 3. Option ticks — 45-day retention ────────────────────────────────────
CREATE TABLE IF NOT EXISTS option_ticks (
    time        TIMESTAMPTZ     NOT NULL,
    symbol      TEXT            NOT NULL,   -- underlying (nifty50, banknifty...)
    expiry      DATE            NOT NULL,
    strike      INT             NOT NULL,
    opttype     TEXT            NOT NULL,   -- CE / PE
    token       TEXT            NOT NULL,
    ltp         NUMERIC(12,2),
    oi          BIGINT,
    volume      BIGINT,
    chg         NUMERIC(12,2),
    chg_pct     NUMERIC(8,4),
    iv          NUMERIC(8,4),              -- implied vol %
    delta       NUMERIC(8,6),
    gamma       NUMERIC(10,8),
    theta       NUMERIC(8,4),
    vega        NUMERIC(8,4)
);
SELECT create_hypertable('option_ticks', 'time', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_option_ticks_token_time ON option_ticks (token, time DESC);
CREATE INDEX IF NOT EXISTS idx_option_ticks_sym_exp_strike ON option_ticks (symbol, expiry, strike, time DESC);
SELECT add_retention_policy('option_ticks', INTERVAL '45 days', if_not_exists => TRUE);

-- ── 4. Option 1-min candles — 45-day retention ────────────────────────────
CREATE TABLE IF NOT EXISTS option_candles_1m (
    time        TIMESTAMPTZ     NOT NULL,
    symbol      TEXT            NOT NULL,
    expiry      DATE            NOT NULL,
    strike      INT             NOT NULL,
    opttype     TEXT            NOT NULL,
    token       TEXT            NOT NULL,
    open        NUMERIC(12,2),
    high        NUMERIC(12,2),
    low         NUMERIC(12,2),
    close       NUMERIC(12,2),
    volume      BIGINT,
    oi          BIGINT,
    iv          NUMERIC(8,4),
    delta       NUMERIC(8,6),
    gamma       NUMERIC(10,8),
    theta       NUMERIC(8,4),
    vega        NUMERIC(8,4),
    PRIMARY KEY (time, token)
);
SELECT create_hypertable('option_candles_1m', 'time', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_opt_candles_sym_exp_strike ON option_candles_1m (symbol, expiry, strike, time DESC);
SELECT add_retention_policy('option_candles_1m', INTERVAL '45 days', if_not_exists => TRUE);

-- ── 5. Global signals (Finnhub polled data) ──────────────────────────────
CREATE TABLE IF NOT EXISTS global_signals (
    time               TIMESTAMPTZ NOT NULL,
    sp500              NUMERIC(12,4),
    sp500_change       NUMERIC(8,4),
    sp500_direction    TEXT,       -- UP / DOWN / FLAT
    nasdaq             NUMERIC(12,4),
    nasdaq_change      NUMERIC(8,4),
    nasdaq_direction   TEXT,
    nikkei             NUMERIC(12,4),
    nikkei_change      NUMERIC(8,4),
    nikkei_direction   TEXT,
    hang_seng          NUMERIC(12,4),
    hang_seng_change   NUMERIC(8,4),
    hang_seng_direction TEXT,
    crude_oil          NUMERIC(12,4),
    gold               NUMERIC(12,4),
    usd_inr            NUMERIC(12,4),
    dxy                NUMERIC(12,4),
    us_10y_yield       NUMERIC(8,4),
    gift_nifty         NUMERIC(12,4),        -- nullable (skipped for now)
    global_alignment   INT,                  -- -3..+3 score
    raw                JSONB
);
SELECT create_hypertable('global_signals', 'time', if_not_exists => TRUE);

-- ── 6. FII/DII daily (nsepython) ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fii_dii_daily (
    date                DATE PRIMARY KEY,
    fii_net_today       NUMERIC(16,2),      -- cash market net
    fii_streak          INT,                -- consecutive days of same direction
    fii_futures         NUMERIC(16,2),
    fii_call_oi         BIGINT,
    fii_put_oi          BIGINT,
    fii_options_bias    TEXT,               -- BULLISH / BEARISH / NEUTRAL
    dii_net_today       NUMERIC(16,2),
    client_bias         TEXT,
    raw                 JSONB,
    fetched_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ── 7. Strategies (dynamic, DB-editable) ─────────────────────────────────
CREATE TABLE IF NOT EXISTS strategies (
    id              SERIAL PRIMARY KEY,
    name            TEXT UNIQUE NOT NULL,
    is_active       BOOLEAN DEFAULT FALSE,
    signal_type     TEXT,                   -- e.g. momentum / mean_reversion
    entry_rules     JSONB,
    exit_rules      JSONB,
    bias_criteria   JSONB,
    risk_rules      JSONB,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Only one strategy active at a time
CREATE UNIQUE INDEX IF NOT EXISTS idx_strategies_one_active
    ON strategies (is_active) WHERE is_active = TRUE;

-- Seed a default momentum strategy if none exists
INSERT INTO strategies (name, is_active, signal_type, entry_rules, exit_rules, bias_criteria, risk_rules)
SELECT
    'default_momentum',
    TRUE,
    'momentum',
    '{"conditions":[
        {"field":"rsi","op":">","value":55},
        {"field":"ema_9","op":">","field2":"ema_21"},
        {"field":"supertrend_dir","op":"==","value":1},
        {"field":"adx","op":">","value":20}
    ],"logic":"AND"}'::jsonb,
    '{"conditions":[
        {"field":"rsi","op":"<","value":45},
        {"field":"ema_9","op":"<","field2":"ema_21"}
    ],"logic":"OR"}'::jsonb,
    '{"global_alignment":">=1","fii_options_bias":"BULLISH","pcr":"<1.0"}'::jsonb,
    '{
        "max_positions":1,
        "position_size_pct":5,
        "sl_atr_mult":1.5,
        "target_atr_mult":3.0,
        "target_symbol":"nifty50",
        "option_selection":{
            "method":"delta",
            "target_delta":0.3,
            "offset_strikes":1,
            "prefer":"OTM"
        },
        "expiry_preference":"weekly"
    }'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM strategies);

-- ── 8. Bot decisions (log of every strategy evaluation) ──────────────────
CREATE TABLE IF NOT EXISTS bot_decisions (
    time             TIMESTAMPTZ NOT NULL,
    strategy_id      INT,
    symbol           TEXT,
    decision         TEXT,       -- ENTRY_BUY / ENTRY_SELL / EXIT / NEUTRAL
    matched_rules    JSONB,
    market_snapshot  JSONB,
    notes            TEXT
);
SELECT create_hypertable('bot_decisions', 'time', if_not_exists => TRUE);
CREATE INDEX IF NOT EXISTS idx_bot_decisions_strategy ON bot_decisions (strategy_id, time DESC);
SELECT add_retention_policy('bot_decisions', INTERVAL '30 days', if_not_exists => TRUE);

-- ── 9. Backfill status tracker ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS backfill_status (
    id              SERIAL PRIMARY KEY,
    symbol          TEXT NOT NULL,
    asset_type      TEXT NOT NULL,          -- 'index' or 'option'
    timeframe       TEXT NOT NULL,          -- 1m / 5m / 15m / 1d
    phase           INT DEFAULT 1,          -- 1 = default scope, 2 = extended
    target_from     TIMESTAMPTZ NOT NULL,
    target_to       TIMESTAMPTZ NOT NULL,
    last_fetched_to TIMESTAMPTZ,
    status          TEXT DEFAULT 'pending', -- pending / running / complete / failed
    retry_count     INT DEFAULT 0,
    next_retry_at   TIMESTAMPTZ,
    error           TEXT,
    progress_pct    NUMERIC(5,2) DEFAULT 0,
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (symbol, asset_type, timeframe, phase)
);
CREATE INDEX IF NOT EXISTS idx_backfill_status_status ON backfill_status (status, next_retry_at);

-- ── 10. System state (tiny K/V for flags) ────────────────────────────────
CREATE TABLE IF NOT EXISTS system_state (
    key     TEXT PRIMARY KEY,
    value   JSONB,
    updated TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO system_state (key, value)
VALUES ('db_initialized_at', to_jsonb(NOW()::TEXT))
ON CONFLICT (key) DO NOTHING;
