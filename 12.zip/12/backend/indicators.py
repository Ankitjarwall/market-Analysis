"""
Technical-indicator computation — pure pandas / numpy.

Intentionally free of pandas_ta / ta-lib to avoid dependency-chain headaches
on Python 3.12. Every indicator is implemented from the textbook formula.

compute_indicators(df) takes an OHLCV DataFrame (columns: open, high, low,
close, volume, indexed by timestamp) and returns a new DataFrame with all
indicator columns added.
"""
import pandas as pd
import numpy as np


INDICATOR_COLS = [
    "rsi", "macd", "macd_signal", "macd_hist",
    "ema_9", "ema_21", "ema_50",
    "vwap", "adx", "atr",
    "bb_upper", "bb_middle", "bb_lower",
    "supertrend", "supertrend_dir",
    "obv",
]


# ── Building blocks ─────────────────────────────────────────────────────────
def _ema(series: pd.Series, length: int) -> pd.Series:
    return series.ewm(span=length, adjust=False).mean()


def _rsi(close: pd.Series, length: int = 14) -> pd.Series:
    delta = close.diff()
    gain  = delta.clip(lower=0)
    loss  = (-delta).clip(lower=0)
    # Wilder smoothing (alpha = 1/N)
    avg_gain = gain.ewm(alpha=1 / length, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / length, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))


def _macd(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    macd = _ema(close, fast) - _ema(close, slow)
    sig  = _ema(macd, signal)
    hist = macd - sig
    return macd, sig, hist


def _true_range(high: pd.Series, low: pd.Series, close: pd.Series) -> pd.Series:
    prev_close = close.shift()
    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low  - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr


def _atr(high, low, close, length: int = 14) -> pd.Series:
    tr = _true_range(high, low, close)
    return tr.ewm(alpha=1 / length, adjust=False).mean()


def _adx(high: pd.Series, low: pd.Series, close: pd.Series, length: int = 14) -> pd.Series:
    up_move   = high.diff()
    down_move = -low.diff()
    plus_dm   = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm  = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)

    tr  = _true_range(high, low, close)
    atr = tr.ewm(alpha=1 / length, adjust=False).mean()

    plus_di  = 100 * pd.Series(plus_dm,  index=close.index).ewm(alpha=1 / length, adjust=False).mean() / atr.replace(0, np.nan)
    minus_di = 100 * pd.Series(minus_dm, index=close.index).ewm(alpha=1 / length, adjust=False).mean() / atr.replace(0, np.nan)

    dx = ((plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)) * 100
    return dx.ewm(alpha=1 / length, adjust=False).mean()


def _vwap(high, low, close, volume) -> pd.Series:
    """VWAP that resets at each daily session boundary.
    Angel One sends cumulative volume, so we derive per-bar volume first."""
    vol = _session_volume(volume)
    tp  = (high + low + close) / 3
    pv  = tp * vol

    # Group by date for daily reset
    if hasattr(close.index, 'date'):
        dates   = close.index.date
        cum_pv  = pv.groupby(dates).cumsum()
        cum_vol = vol.groupby(dates).cumsum().replace(0, np.nan)
    else:
        cum_pv  = pv.cumsum()
        cum_vol = vol.cumsum().replace(0, np.nan)
    return cum_pv / cum_vol


def _session_volume(volume: pd.Series) -> pd.Series:
    """Angel One sends cumulative daily volume. Convert to per-bar delta.
    If values are already per-bar (non-cumulative), this is a no-op because
    diff would produce reasonable values anyway."""
    if volume.empty:
        return volume
    # Detect cumulative: if values are monotonically non-decreasing within each day
    if hasattr(volume.index, 'date'):
        groups = volume.groupby(volume.index.date)
        deltas = []
        for _, grp in groups:
            d = grp.diff()
            d.iloc[0] = grp.iloc[0]   # first bar of day keeps its value
            deltas.append(d)
        return pd.concat(deltas).clip(lower=0)
    # Fallback: assume per-bar
    return volume


def _bbands(close: pd.Series, length: int = 20, std: float = 2.0):
    mid   = close.rolling(length).mean()
    sd    = close.rolling(length).std()
    upper = mid + std * sd
    lower = mid - std * sd
    return upper, mid, lower


def _supertrend(high: pd.Series, low: pd.Series, close: pd.Series,
                length: int = 10, multiplier: float = 3.0):
    """Classic Supertrend (ATR-based trailing stop)."""
    atr = _atr(high, low, close, length)
    hl2 = (high + low) / 2
    upper_band = hl2 + multiplier * atr
    lower_band = hl2 - multiplier * atr

    n = len(close)
    if n == 0:
        return pd.Series(dtype=float), pd.Series(dtype="Int64")

    # Work with numpy arrays for speed
    c  = close.to_numpy(dtype=float)
    ub = upper_band.to_numpy(dtype=float)
    lb = lower_band.to_numpy(dtype=float)

    st       = np.full(n, np.nan)
    direction = np.zeros(n, dtype=np.int8)

    # Seed
    st[0] = ub[0]
    direction[0] = 1 if c[0] > ub[0] else -1

    for i in range(1, n):
        # Lock bands so they only "trail" in one direction
        if not np.isnan(ub[i - 1]) and ub[i] > ub[i - 1] and c[i - 1] <= ub[i - 1]:
            ub[i] = ub[i - 1]
        if not np.isnan(lb[i - 1]) and lb[i] < lb[i - 1] and c[i - 1] >= lb[i - 1]:
            lb[i] = lb[i - 1]

        # Determine direction
        if direction[i - 1] == 1:
            if c[i] < lb[i]:
                direction[i] = -1
                st[i] = ub[i]
            else:
                direction[i] = 1
                st[i] = lb[i]
        else:
            if c[i] > ub[i]:
                direction[i] = 1
                st[i] = lb[i]
            else:
                direction[i] = -1
                st[i] = ub[i]

    return (
        pd.Series(st, index=close.index, name="supertrend"),
        pd.Series(direction, index=close.index, name="supertrend_dir").astype("Int64"),
    )


def _obv(close: pd.Series, volume: pd.Series) -> pd.Series:
    vol = _session_volume(volume)
    direction = np.sign(close.diff()).fillna(0)
    return (direction * vol).cumsum()


# ── Main entry point ───────────────────────────────────────────────────────
def compute_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """
    Returns df with indicator columns added. df must have columns:
      open, high, low, close, volume
    and be indexed by a DatetimeIndex (ascending).

    Rows where there isn't enough history will have NaN values.
    Every indicator call is wrapped in try/except so a failure in one
    indicator never breaks the rest — failing columns just stay NaN.
    """
    if df is None or df.empty:
        return df

    df = df.copy()
    for col in ("open", "high", "low", "close", "volume"):
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    close  = df["close"]
    high   = df["high"]
    low    = df["low"]
    volume = df["volume"]

    try:    df["rsi"] = _rsi(close)
    except Exception as e: print(f"[ind] rsi: {e}"); df["rsi"] = np.nan

    try:
        macd, sig, hist = _macd(close)
        df["macd"]        = macd
        df["macd_signal"] = sig
        df["macd_hist"]   = hist
    except Exception as e:
        print(f"[ind] macd: {e}")
        df["macd"] = df["macd_signal"] = df["macd_hist"] = np.nan

    try:
        df["ema_9"]  = _ema(close, 9)
        df["ema_21"] = _ema(close, 21)
        df["ema_50"] = _ema(close, 50)
    except Exception as e:
        print(f"[ind] ema: {e}")
        df["ema_9"] = df["ema_21"] = df["ema_50"] = np.nan

    try:    df["vwap"] = _vwap(high, low, close, volume)
    except Exception as e: print(f"[ind] vwap: {e}"); df["vwap"] = np.nan

    try:    df["adx"] = _adx(high, low, close)
    except Exception as e: print(f"[ind] adx: {e}"); df["adx"] = np.nan

    try:    df["atr"] = _atr(high, low, close)
    except Exception as e: print(f"[ind] atr: {e}"); df["atr"] = np.nan

    try:
        upper, mid, lower = _bbands(close)
        df["bb_upper"]  = upper
        df["bb_middle"] = mid
        df["bb_lower"]  = lower
    except Exception as e:
        print(f"[ind] bbands: {e}")
        df["bb_upper"] = df["bb_middle"] = df["bb_lower"] = np.nan

    try:
        st_line, st_dir = _supertrend(high, low, close)
        df["supertrend"]     = st_line
        df["supertrend_dir"] = st_dir
    except Exception as e:
        print(f"[ind] supertrend: {e}")
        df["supertrend"] = df["supertrend_dir"] = np.nan

    try:    df["obv"] = _obv(close, volume)
    except Exception as e: print(f"[ind] obv: {e}"); df["obv"] = np.nan

    return df


def latest_indicator_row(df: pd.DataFrame) -> dict:
    """Returns the last row's indicator values as a plain dict (None for NaN)."""
    if df is None or df.empty:
        return {c: None for c in INDICATOR_COLS}
    row = df.iloc[-1]
    out = {}
    for col in INDICATOR_COLS:
        if col not in df.columns:
            out[col] = None
            continue
        val = row[col]
        if pd.isna(val):
            out[col] = None
        elif col in ("obv", "supertrend_dir"):
            out[col] = int(val)
        else:
            out[col] = float(val)
    return out
