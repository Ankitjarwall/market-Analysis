"""
APScheduler-driven cron tasks.

Tasks:
  - global signals poll: handled by global_signals.loop_poller() (already a loop)
  - fii_dii fetch:        daily at 19:30 IST
  - backfill retry sweep: every 30 minutes
  - strategy evaluation:  every minute (during market hours)
"""
import asyncio
from datetime import datetime, timezone, timedelta

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

import historical
import fii_dii
import strategy_engine

IST = timezone(timedelta(hours=5, minutes=30))

scheduler: AsyncIOScheduler | None = None


def start():
    global scheduler
    if scheduler is not None:
        return scheduler

    scheduler = AsyncIOScheduler(timezone=IST)

    # FII/DII every day at 19:30 IST (Mon-Fri only)
    scheduler.add_job(
        fii_dii.fetch_and_store,
        CronTrigger(hour=19, minute=30, day_of_week="mon-fri", timezone=IST),
        id="fii_dii_daily",
        replace_existing=True,
    )

    # Backfill retry sweep every 30 minutes
    scheduler.add_job(
        historical.run_pending,
        IntervalTrigger(minutes=30),
        id="backfill_retry",
        replace_existing=True,
    )

    # Strategy evaluation every minute
    scheduler.add_job(
        strategy_engine.evaluate_once,
        IntervalTrigger(seconds=60),
        id="strategy_eval",
        replace_existing=True,
    )

    scheduler.start()
    print("[sched] scheduler started:")
    for j in scheduler.get_jobs():
        print(f"        - {j.id:20s} next={j.next_run_time}")
    return scheduler


async def stop():
    global scheduler
    if scheduler is not None:
        scheduler.shutdown(wait=False)
        scheduler = None
