# Backend — Market Data API

Live index data from Angel One SmartAPI, streamed over WebSocket using FastAPI.

---

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Setup](#setup)
4. [Environment Variables](#environment-variables)
5. [Indices & Tokens](#indices--tokens)
6. [Code Walkthrough](#code-walkthrough)
   - [Authentication](#authentication)
   - [Angel One WebSocket Feed](#angel-one-websocket-feed)
   - [Thread Bridge (Queue)](#thread-bridge-queue)
   - [Tick Parser](#tick-parser)
   - [Connection Manager](#connection-manager)
   - [App Startup](#app-startup)
7. [API Reference](#api-reference)
   - [REST Endpoints](#rest-endpoints)
   - [WebSocket Endpoints](#websocket-endpoints)
8. [Tick Payload Schema](#tick-payload-schema)
9. [How to Run](#how-to-run)
10. [Common Errors](#common-errors)

---

## Overview

This backend connects to **Angel One SmartAPI** via WebSocket to receive real-time tick data for 5 major Indian market indices:

| Index | Exchange |
|-------|----------|
| NIFTY 50 | NSE |
| BANK NIFTY | NSE |
| FIN NIFTY | NSE |
| MIDCAP SELECT | NSE |
| SENSEX | BSE |

It then re-broadcasts those ticks to any frontend clients connected via its own WebSocket endpoints.

---

## Architecture

```
Angel One SmartAPI
      │
      │  WebSocket (binary/JSON ticks)
      ▼
 Background Thread
 (SmartWebSocketV2)
      │
      │  puts raw ticks into
      ▼
  queue.Queue          ← thread-safe FIFO buffer
      │
      │  async task reads every 10ms
      ▼
 _process_ticks()
      │
      ├── updates latest{}  (in-memory cache)
      │
      └── ConnectionManager.broadcast()
              │
              ├── /ws/nifty50    → subscribers
              ├── /ws/banknifty  → subscribers
              ├── /ws/finnifty   → subscribers
              ├── /ws/midcap     → subscribers
              ├── /ws/sensex     → subscribers
              └── /ws/all        → subscribers
```

**Why a thread + queue?**
Angel One's `SmartWebSocketV2` is built on `websocket-client`, which is synchronous and blocking — it cannot run inside Python's asyncio event loop. So it runs in a **daemon thread**, and ticks are passed to the async world via a `queue.Queue`. The async task `_process_ticks()` polls that queue every 10 ms and broadcasts to WebSocket clients.

---

## Setup

```bash
cd backend
pip install -r requirements.txt
```

**requirements.txt**
```
smartapi-python     # Angel One SmartAPI SDK
pyotp               # Generates TOTP codes for 2FA login
python-dotenv       # Reads .env file
websocket-client    # Dependency of SmartWebSocketV2
fastapi             # Web framework
uvicorn[standard]   # ASGI server to run FastAPI
```

---

## Environment Variables

Stored in `backend/.env`:

```env
ANGEL_API_KEY    = <your API key>
ANGEL_CLIENT_ID  = <your client ID, e.g. A123456>
ANGEL_PASSWORD   = <your 4-digit MPIN>
ANGEL_TOTP_TOKEN = <32-character TOTP secret>
```

| Variable | Where to find it |
|----------|-----------------|
| `ANGEL_API_KEY` | Angel One developer portal → My Apps |
| `ANGEL_CLIENT_ID` | Your Angel One login ID |
| `ANGEL_PASSWORD` | Your 4-digit MPIN |
| `ANGEL_TOTP_TOKEN` | The 32-char secret shown when you enable TOTP in your Angel One account |

---

## Indices & Tokens

Each index is identified by an exchange type and a numeric token assigned by the exchange.

```python
INDICES = {
    "nifty50":   {"exchangeType": 1, "token": "26000", "label": "NIFTY 50"},
    "banknifty": {"exchangeType": 1, "token": "26009", "label": "BANK NIFTY"},
    "finnifty":  {"exchangeType": 1, "token": "26037", "label": "FIN NIFTY"},
    "midcap":    {"exchangeType": 1, "token": "26074", "label": "MIDCAP SELECT"},
    "sensex":    {"exchangeType": 3, "token": "1",     "label": "SENSEX"},
}
```

- `exchangeType: 1` = NSE (National Stock Exchange)
- `exchangeType: 3` = BSE (Bombay Stock Exchange)

`TOKEN_TO_KEY` is a reverse lookup dictionary — maps a raw token string back to its index key (e.g. `"26009"` → `"banknifty"`). Used in the tick parser to identify which index a tick belongs to.

---

## Code Walkthrough

### Authentication

```python
def authenticate() -> tuple[str, str]:
    totp = pyotp.TOTP(TOTP_TOKEN).now()
    obj  = SmartConnect(api_key=API_KEY)
    resp = obj.generateSession(CLIENT_ID, PASSWORD, totp)
    auth_token = resp["data"]["jwtToken"]
    feed_token = obj.getfeedToken()
    return auth_token, feed_token
```

**Step-by-step:**

1. **TOTP** — Angel One requires two-factor authentication. `pyotp.TOTP(TOTP_TOKEN).now()` generates the current 6-digit OTP from your 32-character secret (same algorithm as Google Authenticator). This code changes every 30 seconds.

2. **SmartConnect** — the REST API client from the `smartapi-python` SDK, initialized with your API key.

3. **generateSession** — logs in with your client ID, MPIN, and TOTP. Returns a JWT `auth_token` (used for REST calls) and a `feed_token` (used specifically for the WebSocket market feed).

4. Both tokens are returned and passed downstream.

---

### Angel One WebSocket Feed

```python
def _start_feed(auth_token, feed_token):
    global sws
    sws = SmartWebSocketV2(
        auth_token=auth_token,
        api_key=API_KEY,
        client_code=CLIENT_ID,
        feed_token=feed_token,
    )
    sws.on_open  = _on_open
    sws.on_data  = _on_data
    sws.on_error = _on_error
    sws.on_close = _on_close
    sws.connect()   # blocks here
```

`SmartWebSocketV2` is the Angel One market data WebSocket client. It connects to Angel One's feed server and calls your callback functions as events occur.

**Callbacks:**

| Callback | When called | What we do |
|----------|-------------|------------|
| `_on_open` | WebSocket connection established | Subscribe to all indices |
| `_on_data` | A tick arrives | Put it in `tick_queue` |
| `_on_error` | Connection error | Print the error |
| `_on_close` | Connection closed | Print notification |

**Subscription payload:**
```python
SUBSCRIPTION = [
    {"exchangeType": 1, "tokens": ["26000", "26009", "26037", "26074"]},  # NSE
    {"exchangeType": 3, "tokens": ["1"]},                                   # BSE
]
```

Tokens are grouped by exchange and sent in a single `subscribe()` call with `MODE = 3` (SnapQuote — full OHLCV data including bid/ask depth).

Subscription modes:
- `1` = LTP only (Last Traded Price)
- `2` = Quote (LTP + best bid/ask)
- `3` = SnapQuote (full OHLCV + market depth)

---

### Thread Bridge (Queue)

```python
tick_queue: queue.Queue = queue.Queue()

def _on_data(wsapp, message):
    tick_queue.put(message)     # called from background thread

async def _process_ticks():
    while True:
        try:
            raw = tick_queue.get_nowait()
            tick = _parse_tick(raw)
            if tick:
                latest[tick["index"]] = tick
                await manager.broadcast(tick["index"], tick)
        except queue.Empty:
            await asyncio.sleep(0.01)   # yield control, check again in 10ms
```

`queue.Queue` is Python's thread-safe FIFO queue. The SmartWebSocket thread writes to it; the asyncio task reads from it. This is the bridge between the two worlds (sync thread ↔ async event loop).

`_process_ticks()` uses `get_nowait()` (non-blocking) instead of `get()` (blocking) so it doesn't stall the event loop. When empty, it sleeps for 10 ms to avoid spinning at 100% CPU.

---

### Tick Parser

```python
def _parse_tick(raw) -> dict | None:
    msg   = json.loads(raw) if isinstance(raw, str) else raw
    token = str(msg.get("token", ""))
    key   = TOKEN_TO_KEY.get(token)

    def p(field):
        return round(msg.get(field, 0) / 100, 2)   # paise → rupees

    ltp   = p("last_traded_price")
    close = p("closed_price")
    chg   = round(ltp - close, 2)
    pct   = round((chg / close * 100) if close else 0, 2)

    return {
        "index": key, "label": ..., "ltp": ltp,
        "open": ..., "high": ..., "low": ..., "close": close,
        "change": chg, "changePct": pct,
        "volume": ..., "ts": ...
    }
```

**Key detail — paise to rupees:**
Angel One sends all prices in **paise** (1 rupee = 100 paise) as integers, e.g., `2247550` means ₹22,475.50. Dividing by `100` converts to rupees.

**Change calculation:**
- `change` = LTP − previous close (in rupees)
- `changePct` = (change / close) × 100

If `token` is not in `TOKEN_TO_KEY`, the tick is for an instrument we didn't subscribe to — returns `None` and is discarded.

---

### Connection Manager

```python
class ConnectionManager:
    def __init__(self):
        self._subs: dict[str, list[WebSocket]] = {k: [] for k in INDICES}
        self._subs["all"] = []

    async def connect(self, channel, ws):
        await ws.accept()
        self._subs[channel].append(ws)

    def disconnect(self, channel, ws):
        self._subs[channel].remove(ws)

    async def broadcast(self, index_key, data):
        targets = self._subs[index_key] + self._subs["all"]
        # deduplicate (a client on /ws/all shouldn't get double messages)
        seen = set()
        for ws in targets:
            if id(ws) in seen: continue
            seen.add(id(ws))
            await ws.send_json(data)
        # remove dead connections
```

Maintains a dictionary of active WebSocket connections grouped by channel:
- `_subs["nifty50"]` — clients subscribed to Nifty 50 only
- `_subs["all"]` — clients subscribed to all indices

On each tick, `broadcast()` sends to both the index-specific list and the "all" list, using `id(ws)` to deduplicate so a client connected to `/ws/all` doesn't accidentally receive the same tick twice.

Dead connections (client disconnected without a clean WebSocketDisconnect) are caught during `send_json` and removed.

---

### App Startup

```python
@app.on_event("startup")
async def startup():
    auth_token, feed_token = authenticate()
    t = threading.Thread(target=_start_feed, args=(auth_token, feed_token), daemon=True)
    t.start()
    asyncio.create_task(_process_ticks())
```

FastAPI calls this once when the server starts:
1. Authenticates with Angel One (REST call)
2. Launches `_start_feed` in a **daemon thread** (daemon=True means it auto-dies when the main process exits — no cleanup needed)
3. Creates the async `_process_ticks` task inside the event loop

---

## API Reference

### REST Endpoints

#### `GET /health`
Check if the server is running.

**Response:**
```json
{
  "status": "ok",
  "indices": ["nifty50", "banknifty", "finnifty", "midcap", "sensex"]
}
```

---

#### `GET /snapshot`
Returns the most recent tick for **all** indices. Useful for initial page load before connecting WebSocket.

**Response:**
```json
{
  "nifty50":   { "ltp": 22475.50, "change": 123.45, ... },
  "banknifty": { "ltp": 48250.00, "change": -80.25, ... },
  ...
}
```

---

#### `GET /snapshot/{index}`
Returns the most recent tick for a **single** index.

**Path parameter:** `nifty50` | `banknifty` | `finnifty` | `midcap` | `sensex`

**Response:** Single tick object (see schema below) or `{"error": "No data yet"}` if the server just started.

---

### WebSocket Endpoints

#### `ws://localhost:8000/ws/all`
Streams live ticks for **all 5 indices**.

On connect: immediately sends a `{"type": "snapshot", "data": {...}}` with the latest known values for all indices so the UI isn't blank.

After that: sends individual tick objects as they arrive (no wrapper).

---

#### `ws://localhost:8000/ws/{index}`
Streams live ticks for a **single index**.

**Path parameter:** `nifty50` | `banknifty` | `finnifty` | `midcap` | `sensex`

On connect: immediately sends the last known tick for that index.

After that: sends individual tick objects as they arrive.

If an invalid index is passed, the server accepts the connection, sends `{"error": "Unknown index '...'"}`, and closes it.

---

## Tick Payload Schema

Every message pushed over WebSocket (and returned by REST snapshot) follows this structure:

```json
{
  "index":     "banknifty",
  "label":     "BANK NIFTY",
  "ltp":       48250.50,
  "open":      48100.00,
  "high":      48520.75,
  "low":       48050.25,
  "close":     48330.00,
  "change":    -79.50,
  "changePct": -0.16,
  "volume":    9823456,
  "ts":        "15:29:45"
}
```

| Field | Type | Description |
|-------|------|-------------|
| `index` | string | Internal key (`nifty50`, `banknifty`, etc.) |
| `label` | string | Display name (`BANK NIFTY`, etc.) |
| `ltp` | float | Last Traded Price in ₹ |
| `open` | float | Day open price in ₹ |
| `high` | float | Day high price in ₹ |
| `low` | float | Day low price in ₹ |
| `close` | float | Previous day close in ₹ |
| `change` | float | LTP − close in ₹ (negative = down) |
| `changePct` | float | % change from previous close |
| `volume` | int | Total traded volume for the day |
| `ts` | string | Exchange timestamp |

---

## How to Run

```bash
cd backend
pip install -r requirements.txt
python main.py
```

Server starts at `http://localhost:8000`.

**Test WebSocket from browser console:**
```js
const ws = new WebSocket("ws://localhost:8000/ws/all");
ws.onmessage = (e) => console.log(JSON.parse(e.data));
```

**Test REST:**
```bash
curl http://localhost:8000/snapshot
curl http://localhost:8000/snapshot/nifty50
```

---

## Common Errors

| Error | Cause | Fix |
|-------|-------|-----|
| `Login failed: Invalid totp` | TOTP secret is wrong or system clock is skewed | Verify `ANGEL_TOTP_TOKEN` matches what Angel One showed; sync system clock |
| `Login failed: Invalid credentials` | Wrong client ID or MPIN | Double-check `ANGEL_CLIENT_ID` and `ANGEL_PASSWORD` in `.env` |
| `No data yet` on snapshot | Server just started, no tick received yet | Wait a few seconds; data only flows during market hours (9:15 AM – 3:30 PM IST) |
| WebSocket closes immediately | Feed token expired | Restart the server — it re-authenticates fresh on each startup |
| Prices look wrong (e.g. 2247550) | You're reading raw paise values | The parser already divides by 100; if you see raw values, you're reading `tick_queue` directly |
