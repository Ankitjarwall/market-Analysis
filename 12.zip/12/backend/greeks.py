"""
Black-Scholes Greeks engine — pure Python / numpy.

Functions:
  bs_price(S, K, T, r, sigma, is_call)   → option price
  implied_vol(S, K, T, r, mkt_price, is_call)  → IV (Newton-Raphson)
  greeks(S, K, T, r, sigma, is_call)     → {delta, gamma, theta, vega, iv}
  greeks_for_chain(spot, strikes_data, T, r)  → [{strike, opttype, iv, delta, gamma, theta, vega}, ...]

Parameters:
  S       = spot / underlying price
  K       = strike price
  T       = time to expiry in years (e.g. 5 days = 5/365)
  r       = risk-free rate (annualized, e.g. 0.07 for 7%)
  sigma   = volatility (annualized, e.g. 0.15 for 15%)
  is_call = True for CE, False for PE
"""
import math

RISK_FREE_RATE = 0.07   # 7% — approximate India risk-free rate

# ── Standard normal CDF (Abramowitz & Stegun approximation) ──────────────────
def _norm_cdf(x: float) -> float:
    a1, a2, a3, a4, a5, p = (
        0.254829592, -0.284496736, 1.421413741, -1.453152027, 1.061405429, 0.3275911
    )
    sign = 1 if x >= 0 else -1
    x = abs(x)
    t = 1.0 / (1.0 + p * x)
    y = 1.0 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * math.exp(-x * x / 2.0)
    return 0.5 * (1.0 + sign * y)


def _norm_pdf(x: float) -> float:
    return math.exp(-0.5 * x * x) / math.sqrt(2.0 * math.pi)


# ── Black-Scholes price ─────────────────────────────────────────────────────
def bs_price(S: float, K: float, T: float, r: float, sigma: float, is_call: bool) -> float:
    if T <= 0 or sigma <= 0 or S <= 0 or K <= 0:
        return max(0, (S - K) if is_call else (K - S))
    sqrt_T = math.sqrt(T)
    d1 = (math.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * sqrt_T)
    d2 = d1 - sigma * sqrt_T
    if is_call:
        return S * _norm_cdf(d1) - K * math.exp(-r * T) * _norm_cdf(d2)
    else:
        return K * math.exp(-r * T) * _norm_cdf(-d2) - S * _norm_cdf(-d1)


# ── Implied Volatility (Newton-Raphson) ──────────────────────────────────────
def implied_vol(S: float, K: float, T: float, r: float, mkt_price: float,
                is_call: bool, max_iter: int = 100, tol: float = 0.001) -> float | None:
    """Returns annualized IV as a decimal (e.g. 0.18 = 18%), or None if it fails."""
    if mkt_price <= 0 or T <= 0 or S <= 0 or K <= 0:
        return None

    # Intrinsic floor check
    intrinsic = max(0, (S - K) if is_call else (K - S))
    if mkt_price < intrinsic:
        return None

    sigma = 0.3   # initial guess
    for _ in range(max_iter):
        price = bs_price(S, K, T, r, sigma, is_call)
        vega  = _vega(S, K, T, r, sigma)
        if vega < 1e-12:
            break
        diff = price - mkt_price
        if abs(diff) < tol:
            break
        sigma -= diff / vega
        if sigma <= 0.001:
            sigma = 0.001
    return sigma if 0.001 < sigma < 5.0 else None


# ── Individual Greeks ────────────────────────────────────────────────────────
def _d1(S, K, T, r, sigma):
    return (math.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * math.sqrt(T))


def _d2(S, K, T, r, sigma):
    return _d1(S, K, T, r, sigma) - sigma * math.sqrt(T)


def delta(S, K, T, r, sigma, is_call) -> float:
    if T <= 0 or sigma <= 0:
        return 1.0 if is_call and S > K else -1.0 if not is_call and S < K else 0.0
    d1 = _d1(S, K, T, r, sigma)
    return _norm_cdf(d1) if is_call else _norm_cdf(d1) - 1.0


def gamma(S, K, T, r, sigma) -> float:
    if T <= 0 or sigma <= 0 or S <= 0:
        return 0.0
    d1 = _d1(S, K, T, r, sigma)
    return _norm_pdf(d1) / (S * sigma * math.sqrt(T))


def _vega(S, K, T, r, sigma) -> float:
    if T <= 0 or sigma <= 0 or S <= 0:
        return 0.0
    d1 = _d1(S, K, T, r, sigma)
    return S * _norm_pdf(d1) * math.sqrt(T)


def vega(S, K, T, r, sigma) -> float:
    """Vega per 1% vol move (divide raw vega by 100)."""
    return _vega(S, K, T, r, sigma) / 100.0


def theta(S, K, T, r, sigma, is_call) -> float:
    """Theta per calendar day (divide annual theta by 365)."""
    if T <= 0 or sigma <= 0 or S <= 0:
        return 0.0
    d1 = _d1(S, K, T, r, sigma)
    d2 = _d2(S, K, T, r, sigma)
    sqrt_T = math.sqrt(T)
    term1 = -(S * _norm_pdf(d1) * sigma) / (2 * sqrt_T)
    if is_call:
        term2 = -r * K * math.exp(-r * T) * _norm_cdf(d2)
    else:
        term2 = r * K * math.exp(-r * T) * _norm_cdf(-d2)
    return (term1 + term2) / 365.0


# ── Convenience: all greeks at once ──────────────────────────────────────────
def greeks(S: float, K: float, T: float, r: float, sigma: float, is_call: bool) -> dict:
    """Returns dict with delta, gamma, theta, vega, iv (=sigma passed in)."""
    return {
        "iv":    round(sigma * 100, 2) if sigma else None,  # as percentage
        "delta": round(delta(S, K, T, r, sigma, is_call), 4),
        "gamma": round(gamma(S, K, T, r, sigma), 6),
        "theta": round(theta(S, K, T, r, sigma, is_call), 2),
        "vega":  round(vega(S, K, T, r, sigma), 2),
    }


def greeks_from_market(S: float, K: float, T: float, r: float,
                       mkt_price: float, is_call: bool) -> dict:
    """Compute IV from market price, then all Greeks from that IV."""
    iv = implied_vol(S, K, T, r, mkt_price, is_call)
    if iv is None:
        return {"iv": None, "delta": None, "gamma": None, "theta": None, "vega": None}
    return greeks(S, K, T, r, iv, is_call)


# ── Strike selection helpers ─────────────────────────────────────────────────
def pick_strike_by_delta(spot: float, strikes_with_greeks: list[dict],
                         target_delta: float = 0.3, is_call: bool = True) -> dict | None:
    """Pick the strike whose |delta| is closest to target_delta."""
    best, best_diff = None, float("inf")
    for s in strikes_with_greeks:
        if s.get("opttype") != ("CE" if is_call else "PE"):
            continue
        d = s.get("delta")
        if d is None:
            continue
        diff = abs(abs(d) - target_delta)
        if diff < best_diff:
            best_diff = diff
            best = s
    return best


def pick_strike_by_iv_skew(spot: float, strikes_with_greeks: list[dict],
                           atm_iv: float | None, is_call: bool = True) -> dict | None:
    """Pick the OTM strike with lowest IV relative to ATM IV (cheapest in vol terms)."""
    if atm_iv is None or atm_iv <= 0:
        return None
    best, best_ratio = None, float("inf")
    for s in strikes_with_greeks:
        if s.get("opttype") != ("CE" if is_call else "PE"):
            continue
        iv = s.get("iv")
        if iv is None or iv <= 0:
            continue
        strike = s.get("strike", 0)
        # Only OTM strikes
        if is_call and strike <= spot:
            continue
        if not is_call and strike >= spot:
            continue
        ratio = iv / atm_iv
        if ratio < best_ratio:
            best_ratio = ratio
            best = s
    return best


def pick_strike_fixed_offset(spot: float, step: int, offset: int = 1,
                             is_call: bool = True) -> int:
    """ATM + offset strikes OTM."""
    atm = round(spot / step) * step
    if is_call:
        return atm + offset * step   # OTM call = above ATM
    else:
        return atm - offset * step   # OTM put = below ATM
