"""
Global signals poller via Finnhub (free tier).

Free-tier supports:
  - US stocks (SPY, QQQ as proxies for S&P 500 and Nasdaq)
  - Forex (OANDA:XAU_USD, OANDA:USD_INR, OANDA:DXY*)
  - Most ETFs

Indices like ^GSPC, ^IXIC, ^N225, ^HSI need premium. We use ETF proxies instead.

Symbols (free-tier compatible):
  sp500         → SPY    (US ETF)
  nasdaq        → QQQ    (US ETF)
  nikkei        → EWJ    (iShares MSCI Japan — Nikkei proxy)
  hang_seng     → EWH    (iShares MSCI Hong Kong)
  crude_oil     → USO    (US Oil Fund ETF)
  gold          → GLD    (SPDR Gold Shares)
  usd_inr       → OANDA:USD_INR   (Forex)
  dxy           → UUP    (US Dollar Bullish ETF — DXY proxy)
  us_10y_yield  → SHY    (Short-term Treasury ETF, used as proxy for yield sentiment)
"""
import os
import json
import asyncio
from datetime import datetime, timezone, timedelta
import requests as req_lib

import db

FINNHUB_KEY = os.getenv("FINNHUB_API_KEY", "")

SYMBOLS = {
    "sp500":    {"sym": "SPY", "kind": "stock", "label": "SPY (S&P 500 proxy)"},
    "nasdaq":   {"sym": "QQQ", "kind": "stock", "label": "QQQ (Nasdaq proxy)"},
    "nikkei":   {"sym": "EWJ", "kind": "stock", "label": "EWJ (Nikkei proxy)"},
    "hang_seng":{"sym": "EWH", "kind": "stock", "label": "EWH (Hang Seng proxy)"},
    "crude_oil":{"sym": "USO", "kind": "stock", "label": "USO (Crude Oil proxy)"},
    "gold":     {"sym": "GLD", "kind": "stock", "label": "GLD (Gold proxy)"},
    "dxy":      {"sym": "UUP", "kind": "stock", "label": "UUP (DXY proxy)"},
    "us_10y":   {"sym": "SHY", "kind": "stock", "label": "SHY (Treasury proxy)"},
    "usd_inr":  {"sym": "USD/INR", "kind": "forex", "label": "USD / INR"},
}

BASE = "https://finnhub.io/api/v1"
IST = timezone(timedelta(hours=5, minutes=30))


def _fetch_quote(symbol: str, kind: str) -> dict | None:
    """Return {'c': price, 'd': change, 'dp': change_pct} or None."""
    if not FINNHUB_KEY:
        return None
    try:
        if kind == "forex":
            # Use /forex/candle with 1-day resolution as a workaround
            # Or try the exchange rate endpoint
            import time as _t
            now = int(_t.time())
            url = f"{BASE}/forex/candle"
            r = req_lib.get(url, params={
                "symbol": f"OANDA:{symbol.replace('/', '_')}",
                "resolution": "D", "from": now - 86400 * 2, "to": now,
                "token": FINNHUB_KEY
            }, timeout=10)
            js = r.json()
            if js.get("s") == "ok" and js.get("c"):
                closes = js["c"]
                c = closes[-1]
                prev = closes[-2] if len(closes) > 1 else c
                d = c - prev
                dp = (d / prev * 100) if prev else 0
                return {"c": round(c, 4), "d": round(d, 4), "dp": round(dp, 2)}
            return None
        else:
            url = f"{BASE}/quote"
            r = req_lib.get(url, params={"symbol": symbol, "token": FINNHUB_KEY}, timeout=10)
            js = r.json()
            if "c" in js and js["c"]:
                return {"c": js["c"], "d": js.get("d", 0), "dp": js.get("dp", 0)}
    except Exception as e:
        print(f"[finnhub] {symbol}: {e}")
    return None


def _direction(change_pct: float | None) -> str:
    if change_pct is None:
        return "FLAT"
    if change_pct >  0.15: return "UP"
    if change_pct < -0.15: return "DOWN"
    return "FLAT"


async def poll_once():
    """Fetch one snapshot of all globals and insert a row."""
    if not FINNHUB_KEY:
        print("[finnhub] no FINNHUB_API_KEY set — skipping poll")
        return

    loop = asyncio.get_event_loop()
    raw = {}
    for key, cfg in SYMBOLS.items():
        raw[key] = await loop.run_in_executor(None, _fetch_quote, cfg["sym"], cfg["kind"])
        await asyncio.sleep(0.6)   # stay under Finnhub's 60/min free limit

    def val(k):
        r = raw.get(k)
        return r["c"] if r else None

    def chg(k):
        r = raw.get(k)
        return r["dp"] if r else None

    sp_dp = chg("sp500")
    nd_dp = chg("nasdaq")
    nk_dp = chg("nikkei")
    hs_dp = chg("hang_seng")

    # Global alignment: count of positive vs negative major indices (-3 .. +3)
    score = 0
    for dp in (sp_dp, nd_dp, nk_dp):
        if dp is None: continue
        score += 1 if dp > 0.15 else -1 if dp < -0.15 else 0

    await db.execute(
        """INSERT INTO global_signals
           (time, sp500, sp500_change, sp500_direction,
            nasdaq, nasdaq_change, nasdaq_direction,
            nikkei, nikkei_change, nikkei_direction,
            hang_seng, hang_seng_change, hang_seng_direction,
            crude_oil, gold, usd_inr, dxy, us_10y_yield,
            gift_nifty, global_alignment, raw)
           VALUES ($1,$2,$3,$4, $5,$6,$7, $8,$9,$10,
                   $11,$12,$13, $14,$15,$16,$17,$18, $19,$20,$21::jsonb)""",
        datetime.now(timezone.utc),
        val("sp500"), sp_dp, _direction(sp_dp),
        val("nasdaq"), nd_dp, _direction(nd_dp),
        val("nikkei"), nk_dp, _direction(nk_dp),
        val("hang_seng"), hs_dp, _direction(hs_dp),
        val("crude_oil"), val("gold"), val("usd_inr"), val("dxy"), val("us_10y"),
        None,           # gift_nifty — skipped
        score,
        json.dumps(raw, default=str),
    )
    print(f"[finnhub] stored snapshot · alignment={score:+d}")


def _is_market_hours() -> bool:
    """India market hours (Mon-Fri 9:00-15:45 IST)"""
    now = datetime.now(IST)
    if now.weekday() >= 5:
        return False
    mins = now.hour * 60 + now.minute
    return 9 * 60 <= mins <= 15 * 60 + 45


async def loop_poller():
    """Infinite loop: poll every 60 s during market hours, every 300 s off-hours."""
    print("[finnhub] poller started")
    while True:
        try:
            await poll_once()
        except Exception as e:
            print(f"[finnhub] poll error: {e}")
        await asyncio.sleep(60 if _is_market_hours() else 300)
