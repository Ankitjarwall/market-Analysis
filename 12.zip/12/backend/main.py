import os
import re
import json
import asyncio
import queue
import threading
import time
import pyotp
import uvicorn
import requests as req_lib
from datetime import datetime, date, timezone, timedelta
from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from SmartApi import SmartConnect
from SmartApi.smartWebSocketV2 import SmartWebSocketV2

# ── New modules (DB, history, scheduler, indicators…) ────────────────────────
import db
import tick_writer
import historical
import global_signals
import strategy_engine
import scheduler as sched_mod

load_dotenv()

API_KEY    = os.getenv("ANGEL_API_KEY")
CLIENT_ID  = os.getenv("ANGEL_CLIENT_ID")
PASSWORD   = os.getenv("ANGEL_PASSWORD")
TOTP_TOKEN = os.getenv("ANGEL_TOTP_TOKEN")

# ── Index WebSocket feed config ───────────────────────────────────────────────
INDICES = {
    "nifty50":   {"exchangeType": 1, "token": "26000", "label": "NIFTY 50"},
    "banknifty": {"exchangeType": 1, "token": "26009", "label": "BANK NIFTY"},
    "finnifty":  {"exchangeType": 1, "token": "26037", "label": "FIN NIFTY"},
    "midcap":    {"exchangeType": 1, "token": "26074", "label": "MIDCAP SELECT"},
    "sensex":    {"exchangeType": 3, "token": "1",     "label": "SENSEX"},
    "indiavix":  {"exchangeType": 1, "token": "26017", "label": "INDIA VIX"},
}
TOKEN_TO_KEY = {v["token"]: k for k, v in INDICES.items()}
SUBSCRIPTION = [
    {"exchangeType": 1, "tokens": [v["token"] for v in INDICES.values() if v["exchangeType"] == 1]},
    {"exchangeType": 3, "tokens": [v["token"] for v in INDICES.values() if v["exchangeType"] == 3]},
]

# ── Option chain config ───────────────────────────────────────────────────────
# name = underlying name in Angel One scripmaster, step = strike interval
OC_SYMBOLS = {
    "nifty50":   {"name": "NIFTY",      "step": 50},
    "banknifty": {"name": "BANKNIFTY",  "step": 100},
    "finnifty":  {"name": "FINNIFTY",   "step": 50},
    "midcap":    {"name": "MIDCPNIFTY", "step": 25},
}

CORRELATION_ID = "indices_stream"
MODE = 3  # SnapQuote

# ── Shared state ──────────────────────────────────────────────────────────────
tick_queue: queue.Queue = queue.Queue()
latest:     dict = {}
feed_status = {"connected": False, "error": None}

app = FastAPI(title="Market Data API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


# ── Connection manager ────────────────────────────────────────────────────────
class ConnectionManager:
    def __init__(self):
        self._subs = {k: [] for k in INDICES}
        self._subs["all"] = []

    async def connect(self, channel, ws):
        await ws.accept()
        self._subs[channel].append(ws)

    def disconnect(self, channel, ws):
        try:
            self._subs[channel].remove(ws)
        except ValueError:
            pass

    async def broadcast(self, index_key, data):
        dead = []
        targets = list(self._subs.get(index_key, [])) + list(self._subs["all"])
        seen = set()
        for ws in targets:
            if id(ws) in seen:
                continue
            seen.add(id(ws))
            try:
                await ws.send_json(data)
            except Exception:
                dead.append((index_key, ws))
        for k, ws in dead:
            self.disconnect(k, ws)
            self.disconnect("all", ws)


manager    = ConnectionManager()
sws        = None
_smart_obj:  SmartConnect | None = None
_auth_token: str = ""

# ── Option chain live state ───────────────────────────────────────────────────
_oc_token_meta:    dict = {}   # token_str -> {strike, opttype, symbol}
_oc_live:          dict = {}   # symbol -> {strike -> {opttype -> data}}
_oc_active_tokens: set  = set()  # currently subscribed option tokens
_oc_active_expiry: dict = {}   # symbol -> expiry_str (for DB persistence)
OC_CORR = "oc_stream"


class OCManager:
    """WebSocket connections for option chain streams."""
    def __init__(self):
        self._subs: dict[str, list[WebSocket]] = {}

    async def connect(self, symbol: str, ws: WebSocket):
        await ws.accept()
        self._subs.setdefault(symbol, []).append(ws)

    def disconnect(self, symbol: str, ws: WebSocket):
        try:
            self._subs[symbol].remove(ws)
        except (ValueError, KeyError):
            pass

    async def broadcast(self, symbol: str, data: dict):
        dead = []
        for ws in list(self._subs.get(symbol, [])):
            try:
                await ws.send_json(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(symbol, ws)


oc_manager = OCManager()


# ── Authentication ────────────────────────────────────────────────────────────
def authenticate():
    global _smart_obj, _auth_token
    totp       = pyotp.TOTP(TOTP_TOKEN).now()
    _smart_obj = SmartConnect(api_key=API_KEY)
    resp       = _smart_obj.generateSession(CLIENT_ID, PASSWORD, totp)
    if not resp.get("status"):
        raise RuntimeError(f"Login failed: {resp.get('message')}")
    _auth_token = resp["data"]["jwtToken"]
    feed_token  = _smart_obj.getfeedToken()
    print(f"[auth] Logged in as {CLIENT_ID}")
    return _auth_token, feed_token


def _angel_headers() -> dict:
    """Build Angel One REST API headers from the saved JWT token.
    Angel One's jwtToken already contains the 'Bearer ' prefix."""
    token = _auth_token.strip()
    if not token.lower().startswith("bearer "):
        token = f"Bearer {token}"
    return {
        "Authorization":    token,
        "Content-Type":     "application/json",
        "Accept":           "application/json",
        "X-UserType":       "USER",
        "X-SourceID":       "WEB",
        "X-ClientLocalIP":  "127.0.0.1",
        "X-ClientPublicIP": "127.0.0.1",
        "X-MACAddress":     "00:00:00:00:00:00",
        "X-PrivateKey":     API_KEY,
    }


def _fmt_ts(ts) -> str:
    """Convert Angel One exchange_timestamp (epoch int or datetime str) to HH:MM:SS."""
    if not ts:
        return ""
    try:
        if isinstance(ts, (int, float)):
            # epoch in ms if > 1e10, else seconds
            return datetime.fromtimestamp(ts / 1000 if ts > 1e10 else ts).strftime("%H:%M:%S")
        s = str(ts).strip()
        # "YYYY-MM-DD HH:MM:SS" or "DD/MM/YYYY HH:MM:SS" — grab the time part
        if " " in s:
            return s.split()[-1][:8]
        return s[:8]
    except Exception:
        return str(ts)[:8]


# ── Angel One WebSocket callbacks ─────────────────────────────────────────────
def _on_open(wsapp):
    feed_status["connected"] = True
    feed_status["error"]     = None
    print("[ws] Connected — subscribing indices…")
    sws.subscribe(CORRELATION_ID, MODE, SUBSCRIPTION)
    # Re-subscribe option tokens if any were active before reconnect
    if _oc_active_tokens:
        sws.subscribe(OC_CORR, MODE, [{"exchangeType": 2, "tokens": list(_oc_active_tokens)}])
        print(f"[ws] Re-subscribed {len(_oc_active_tokens)} option tokens")

def _on_data(wsapp, message):
    tick_queue.put(message)

def _on_error(wsapp, error):
    feed_status["connected"] = False
    feed_status["error"]     = str(error)
    print(f"[ws] Error: {error}")

def _on_close(wsapp):
    feed_status["connected"] = False
    print("[ws] Connection closed")

def _start_feed(auth_token, feed_token):
    global sws
    sws = SmartWebSocketV2(
        auth_token=auth_token, api_key=API_KEY,
        client_code=CLIENT_ID, feed_token=feed_token,
    )
    sws.on_open  = _on_open
    sws.on_data  = _on_data
    sws.on_error = _on_error
    sws.on_close = _on_close
    sws.connect()


# ── Tick processor ────────────────────────────────────────────────────────────
def _parse_tick(msg):
    try:
        if isinstance(msg, str):
            msg = json.loads(msg)
        token = str(msg.get("token", ""))
        key   = TOKEN_TO_KEY.get(token)
        if not key:
            return None
        def p(f): return round(msg.get(f, 0) / 100, 2)
        ltp   = p("last_traded_price")
        close = p("closed_price")
        chg   = round(ltp - close, 2)
        pct   = round((chg / close * 100) if close else 0, 2)
        return {
            "index": key, "label": INDICES[key]["label"],
            "ltp": ltp, "open": p("open_price_of_the_day"),
            "high": p("high_price_of_the_day"), "low": p("low_price_of_the_day"),
            "close": close, "change": chg, "changePct": pct,
            "volume": msg.get("volume_trade_for_the_day", 0),
            "ts": _fmt_ts(msg.get("exchange_timestamp", "")),
        }
    except Exception as e:
        print(f"[parse error] {e}")
        return None


def _parse_option_tick(msg: dict, meta: dict) -> dict | None:
    """Parse a raw SmartWebSocket tick for an option contract."""
    try:
        def p(f): return round(msg.get(f, 0) / 100, 2)
        ltp   = p("last_traded_price")
        close = p("closed_price")
        chg   = round(ltp - close, 2)
        pct   = round((chg / close * 100) if close else 0, 2)
        return {
            "strike":    meta["strike"],
            "opttype":   meta["opttype"],
            "symbol":    meta["symbol"],
            "ltp":       ltp,
            "oi":        msg.get("open_interest", 0),
            "volume":    msg.get("volume_trade_for_the_day", 0),
            "change":    chg,
            "changePct": pct,
        }
    except Exception as e:
        print(f"[oc tick error] {e}")
        return None


async def _process_ticks():
    while True:
        try:
            raw = tick_queue.get_nowait()
        except queue.Empty:
            await asyncio.sleep(0.01)
            continue
        try:
            msg   = json.loads(raw) if isinstance(raw, str) else raw
            token = str(msg.get("token", ""))

            if token in TOKEN_TO_KEY:
                tick = _parse_tick(msg)
                if tick:
                    latest[tick["index"]] = tick
                    await manager.broadcast(tick["index"], tick)
                    # Persist to DB
                    try:
                        await tick_writer.push_index_tick(tick["index"], token, tick)
                    except Exception as e:
                        print(f"[tick persist] {e}")

            elif token in _oc_token_meta:
                meta = _oc_token_meta[token]
                opt  = _parse_option_tick(msg, meta)
                if opt:
                    sym     = meta["symbol"]
                    strike  = meta["strike"]
                    opttype = meta["opttype"]
                    _oc_live.setdefault(sym, {}).setdefault(strike, {})[opttype] = opt
                    await oc_manager.broadcast(sym, {"type": "tick", "data": opt})
                    # Persist to DB (expiry comes from _oc_active_expiry set in /optionchain)
                    try:
                        exp_str = _oc_active_expiry.get(sym, "")
                        if exp_str:
                            await tick_writer.push_option_tick(
                                sym, exp_str, strike, opttype, token, opt
                            )
                    except Exception as e:
                        print(f"[opt tick persist] {e}")
        except Exception as e:
            print(f"[tick error] {e}")


# ── Angel One Scripmaster (token lookup for options) ──────────────────────────
SM_URL       = "https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json"
_scripmaster: list = []
_sm_ready    = False


def _load_scripmaster():
    global _scripmaster, _sm_ready
    try:
        print("[sm] Downloading scripmaster (~5 MB)…")
        r = req_lib.get(SM_URL, timeout=60)
        raw = r.json()
        # Keep only NFO options (OPTIDX = index options)
        _scripmaster = [
            x for x in raw
            if x.get("exch_seg") == "NFO" and "OPT" in x.get("instrumenttype", "")
        ]
        _sm_ready = True
        print(f"[sm] Ready — {len(_scripmaster)} NFO option records loaded")
    except Exception as e:
        print(f"[sm error] {e}")


def _parse_exp_date(exp_str: str):
    """Try parsing expiry string in both 2-digit and 4-digit year formats."""
    for fmt in ("%d%b%Y", "%d%b%y"):   # e.g. 24APR2026 or 24APR26
        try:
            return datetime.strptime(exp_str, fmt).date()
        except Exception:
            pass
    return None


def _get_expiries(name: str) -> list[tuple]:
    """Return sorted list of (date, raw_exp_str) for future expiries of this name."""
    today = date.today()
    seen, result = set(), []
    for rec in _scripmaster:
        if rec.get("name", "").upper() != name.upper():
            continue
        exp_str = rec.get("expiry", "").strip().upper()
        if not exp_str or exp_str in seen:
            continue
        exp_date = _parse_exp_date(exp_str)
        if exp_date and exp_date >= today:
            seen.add(exp_str)
            result.append((exp_date, exp_str))
    return sorted(result)


def _find_tokens(name: str, expiry_str: str, strikes_int: set) -> dict:
    """
    Returns { (strike:int, opttype:'CE'|'PE') : token_str }
    for all strikes in strikes_int at the given expiry.

    Scripmaster format confirmed:
      symbol  = "NIFTY13APR2624000CE"  (NAME + DDMMMYY + STRIKE + CE|PE)
      strike  = "2400000.000000"       (strike price × 100)
    """
    result   = {}
    name_u   = name.upper()
    expiry_u = expiry_str.upper()

    for rec in _scripmaster:
        if rec.get("name", "").upper() != name_u:
            continue
        if rec.get("expiry", "").upper() != expiry_u:
            continue

        # Strike is always stored ×100 — divide unconditionally
        try:
            strike = int(round(float(rec.get("strike", 0)) / 100))
        except Exception:
            continue

        if strike not in strikes_int:
            continue

        # Symbol ends with "CE" or "PE"  e.g. NIFTY13APR2624000CE
        sym = rec.get("symbol", "")
        m   = re.search(r'(CE|PE)$', sym)
        if not m:
            continue

        result[(strike, m.group(1))] = rec["token"]

    return result


def _bulk_quote(tokens: list) -> list:
    """Call Angel One's market quote API for multiple NFO tokens."""
    if not _smart_obj or not tokens:
        return []
    try:
        url     = "https://apiconnect.angelone.in/rest/secure/angelbroking/market/v1/quote/"
        payload = {"mode": "FULL", "exchangeTokens": {"NFO": tokens}}
        r       = req_lib.post(url, json=payload, headers=_angel_headers(), timeout=15)
        data     = r.json()
        status   = data.get("status") if isinstance(data, dict) else None
        message  = data.get("message","") if isinstance(data, dict) else str(data)
        print(f"[quote raw] status={status} msg={message}")
        inner    = data.get("data", {}) if isinstance(data, dict) else {}
        fetched  = inner.get("fetched", []) if isinstance(inner, dict) else []
        if fetched:
            print(f"[quote] {len(fetched)}/{len(tokens)} OK — keys: {list(fetched[0].keys())}")
        else:
            print(f"[quote] 0 fetched — full response: {data}")
        return fetched
    except Exception as e:
        print(f"[quote error] {e}")
        return []


# ── App startup ───────────────────────────────────────────────────────────────
@app.on_event("startup")
async def startup():
    try:
        # 1. Connect to Postgres / TimescaleDB
        await db.init()

        # 2. Authenticate with Angel One
        auth_token, feed_token = authenticate()

        # 3. Start Angel One WebSocket in a daemon thread
        t = threading.Thread(target=_start_feed, args=(auth_token, feed_token), daemon=True)
        t.start()

        # 4. Async tasks
        asyncio.create_task(_process_ticks())
        asyncio.create_task(tick_writer.tick_flusher())
        asyncio.create_task(tick_writer.minute_aggregator())
        asyncio.create_task(asyncio.to_thread(_load_scripmaster))

        # 5. Register historical backfill & kick it off in background
        historical.register(_angel_headers, INDICES)
        asyncio.create_task(historical.start_background())

        # 6. Start Finnhub poller + APScheduler
        asyncio.create_task(global_signals.loop_poller())
        sched_mod.start()
        print("[app] APScheduler started (strategy_eval every 60s)")

        # 7. Strategy engine kickstarter — runs evaluate_once immediately and
        #    then every 60s as a belt-and-suspenders fallback to APScheduler,
        #    so the Live Decision panel starts populating as soon as candles exist.
        async def _strategy_loop():
            # Wait a few seconds so DB + first candle have a chance to land
            await asyncio.sleep(10)
            while True:
                try:
                    await strategy_engine.evaluate_once()
                except Exception as e:
                    print(f"[strategy-loop] error: {e}")
                await asyncio.sleep(60)
        asyncio.create_task(_strategy_loop())

        # 8. Create paper_trades table if not exists
        await db.execute("""
            CREATE TABLE IF NOT EXISTS paper_trades (
                id            SERIAL PRIMARY KEY,
                time          TIMESTAMPTZ DEFAULT NOW(),
                symbol        TEXT NOT NULL,
                strike        INT,
                opttype       TEXT,
                action        TEXT NOT NULL,
                qty           INT NOT NULL,
                lot_size      INT NOT NULL DEFAULT 1,
                price         NUMERIC(12,2) NOT NULL,
                sl_price      NUMERIC(12,2),
                target_price  NUMERIC(12,2),
                status        TEXT NOT NULL DEFAULT 'OPEN',
                exit_price    NUMERIC(12,2),
                exit_time     TIMESTAMPTZ,
                pnl           NUMERIC(12,2),
                strategy_id   INT,
                notes         TEXT
            )
        """)

        print("[app] Startup complete.")
    except Exception as e:
        feed_status["error"] = str(e)
        print(f"[startup error] {e}")


@app.on_event("shutdown")
async def shutdown():
    await sched_mod.stop()
    await db.close()


# ── REST: Health & snapshots ──────────────────────────────────────────────────
@app.get("/health")
def health():
    return {
        "status":        "ok",
        "feed":          feed_status,
        "scripmaster":   {"ready": _sm_ready, "records": len(_scripmaster)},
        "indices":       list(INDICES.keys()),
    }

@app.get("/snapshot")
def snapshot():
    return latest

@app.get("/snapshot/{index}")
def snapshot_index(index: str):
    if index not in INDICES:
        return {"error": f"Unknown index. Valid: {list(INDICES.keys())}"}
    return latest.get(index, {"error": "No data yet"})


# ── DEBUG: inspect raw scripmaster ───────────────────────────────────────────
@app.get("/debug/{symbol}")
async def debug_sm(symbol: str):
    cfg = OC_SYMBOLS.get(symbol)
    if not cfg:
        return {"error": "unknown symbol"}
    name = cfg["name"]
    # Sample 5 raw records for this name
    samples = [r for r in _scripmaster if r.get("name","").upper() == name.upper()][:5]
    expiries = await asyncio.to_thread(_get_expiries, name)
    ltp = latest.get(symbol, {}).get("ltp", 0)
    return {
        "sm_total_records": len(_scripmaster),
        "name_records_sample": samples,
        "expiries_found": [e[1] for e in expiries[:10]],
        "live_ltp": ltp,
    }


# ── REST: Option chain (Angel One data) ──────────────────────────────────────
@app.get("/optionchain/{symbol}")
async def option_chain(symbol: str, expiry: str = ""):
    cfg = OC_SYMBOLS.get(symbol)
    if not cfg:
        return {"error": f"Unsupported symbol. Use: {list(OC_SYMBOLS.keys())}"}

    if not _sm_ready:
        return {"error": "Scripmaster still loading — retry in a few seconds"}

    name = cfg["name"]
    step = cfg["step"]

    # Live price comes from Angel One WebSocket (already streaming)
    ltp = latest.get(symbol, {}).get("ltp", 0)
    if not ltp:
        return {"error": "No live price yet — wait for Angel One WebSocket to connect"}

    # Expiry list
    expiries = await asyncio.to_thread(_get_expiries, name)
    if not expiries:
        return {"error": f"No expiry data for {name} in scripmaster"}

    exp_strs = [e[1] for e in expiries[:8]]   # e.g. ["24APR2025","01MAY2025",...]
    chosen   = expiry if expiry in exp_strs else exp_strs[0]

    # ATM ± 10 strikes
    atm         = round(ltp / step) * step
    strikes_int = set(atm + i * step for i in range(-10, 11))

    # Find tokens from scripmaster
    token_map = await asyncio.to_thread(_find_tokens, name, chosen, strikes_int)
    if not token_map:
        return {"error": f"No option tokens found for {name} expiry={chosen}. "
                         f"Scripmaster has {len(_scripmaster)} records."}

    # Bulk quote from Angel One
    quotes = await asyncio.to_thread(_bulk_quote, list(token_map.values()))

    # Angel One may use "symbolToken" or "token" as the key — handle both
    quote_by_token: dict = {}
    for q in quotes:
        key = (q.get("symbolToken") or q.get("token") or "")
        if key:
            quote_by_token[str(key)] = q

    # Build chain map + seed _oc_live with initial snapshot
    chain_map: dict = {}
    for (strike, opttype), token in token_map.items():
        if strike not in chain_map:
            chain_map[strike] = {"strike": float(strike)}
        q        = quote_by_token.get(str(token), {})
        opt_data = {
            "ltp":       q.get("ltp", 0) or q.get("close", 0),
            "oi":        q.get("opnInterest", 0) or q.get("openInterest", 0),
            "oiChg":     0,
            "volume":    q.get("tradeVolume", 0) or q.get("volume", 0),
            "iv":        0,
            "change":    q.get("netChange", 0),
            "changePct": q.get("percentChange", 0),
        }
        chain_map[strike][opttype] = opt_data
        _oc_live.setdefault(symbol, {}).setdefault(strike, {})[opttype] = opt_data

    all_strikes = sorted(chain_map.keys())
    atm_f       = float(atm)
    atm_strike  = min(all_strikes, key=lambda x: abs(x - atm_f)) if all_strikes else atm_f

    # ── Subscribe option tokens to SmartWebSocket for live streaming ──────────
    new_tokens = list(token_map.values())
    if sws and feed_status["connected"]:
        # Unsubscribe previously active option tokens
        if _oc_active_tokens:
            try:
                sws.unsubscribe(OC_CORR, MODE,
                                [{"exchangeType": 2, "tokens": list(_oc_active_tokens)}])
            except Exception as e:
                print(f"[ws unsub] {e}")
        # Subscribe new tokens (exchangeType 2 = NFO)
        sws.subscribe(OC_CORR, MODE, [{"exchangeType": 2, "tokens": new_tokens}])
        print(f"[ws] Subscribed {len(new_tokens)} option tokens for {symbol} {chosen}")

    # Update global token metadata
    _oc_active_tokens.clear()
    _oc_active_tokens.update(new_tokens)
    _oc_token_meta.clear()
    for (strike, opttype), token in token_map.items():
        _oc_token_meta[token] = {"strike": strike, "opttype": opttype, "symbol": symbol}
    _oc_active_expiry[symbol] = chosen

    return {
        "symbol":      symbol,
        "underlying":  latest.get(symbol, {}).get("ltp", ltp),
        "atmStrike":   atm_strike,
        "expiry":      chosen,
        "expiryDates": exp_strs,
        "chain":       [chain_map[s] for s in all_strikes],
    }


# ══════════════════════════════════════════════════════════════════════════════
#  AUTO-TRADING ENDPOINTS (read-only bot brain)
# ══════════════════════════════════════════════════════════════════════════════

from decimal import Decimal

def _jsonify(v):
    """Convert DB row values into JSON-safe Python primitives."""
    if v is None: return None
    if isinstance(v, Decimal): return float(v)
    if isinstance(v, (datetime, date)): return v.isoformat()
    if isinstance(v, (bytes, bytearray)): return v.decode("utf-8", "ignore")
    if isinstance(v, dict):  return {k: _jsonify(x) for k, x in v.items()}
    if isinstance(v, list):  return [_jsonify(x) for x in v]
    return v

def _row(row):
    """asyncpg Record -> JSON-safe dict."""
    if row is None: return None
    return {k: _jsonify(v) for k, v in dict(row).items()}


@app.get("/autotrade/status")
async def at_status():
    """High-level health of all pipelines."""
    try:
        total_idx = await db.fetchval("SELECT COUNT(*) FROM candles_1m")
        total_opt = await db.fetchval("SELECT COUNT(*) FROM option_candles_1m")
        total_tick = await db.fetchval("SELECT COUNT(*) FROM raw_ticks")
        latest_gs = await db.fetchrow("SELECT time FROM global_signals ORDER BY time DESC LIMIT 1")
        latest_fd = await db.fetchrow("SELECT date FROM fii_dii_daily ORDER BY date DESC LIMIT 1")
    except Exception as e:
        return {"error": str(e)}

    return {
        "feed":              feed_status,
        "candles_1m_count":  int(total_idx or 0),
        "option_candles_1m": int(total_opt or 0),
        "raw_ticks_count":   int(total_tick or 0),
        "global_signals_latest": latest_gs["time"].isoformat() if latest_gs else None,
        "fii_dii_latest_date":  latest_fd["date"].isoformat() if latest_fd else None,
    }


@app.get("/autotrade/backfill")
async def at_backfill():
    rows = await db.fetch(
        """SELECT symbol, timeframe, phase, status, progress_pct,
                  retry_count, next_retry_at, error, updated_at
             FROM backfill_status
            ORDER BY phase, symbol, timeframe"""
    )
    return [_row(r) for r in rows]


@app.get("/autotrade/indicators")
async def at_indicators(symbol: str = "nifty50"):
    row = await db.fetchrow(
        """SELECT * FROM candles_1m
            WHERE symbol = $1
            ORDER BY time DESC LIMIT 1""",
        symbol
    )
    return _row(row) or {}


@app.get("/autotrade/signals")
async def at_signals(limit: int = 1):
    rows = await db.fetch(
        "SELECT * FROM global_signals ORDER BY time DESC LIMIT $1", limit
    )
    return [_row(r) for r in rows]


@app.get("/autotrade/fii-dii")
async def at_fii_dii(days: int = 10):
    rows = await db.fetch(
        "SELECT * FROM fii_dii_daily ORDER BY date DESC LIMIT $1", days
    )
    return [_row(r) for r in rows]


@app.get("/autotrade/options-snapshot")
async def at_options_snapshot(symbol: str = "nifty50"):
    """ATM strike, ATM CE/PE LTP, PCR, VIX — latest snapshot."""
    spot = latest.get(symbol, {}).get("ltp", 0)
    vix  = latest.get("indiavix", {}).get("ltp", 0)
    data = {"symbol": symbol, "spot": spot, "india_vix": vix}

    chain = _oc_live.get(symbol, {})
    if chain and spot:
        # ATM strike = closest key
        atm = min(chain.keys(), key=lambda k: abs(k - spot))
        data["atm_strike"] = atm
        data["atm_ce_ltp"] = chain[atm].get("CE", {}).get("ltp")
        data["atm_pe_ltp"] = chain[atm].get("PE", {}).get("ltp")

        total_ce = sum((v.get("CE") or {}).get("oi", 0) or 0 for v in chain.values())
        total_pe = sum((v.get("PE") or {}).get("oi", 0) or 0 for v in chain.values())
        data["total_oi_calls"] = total_ce
        data["total_oi_puts"]  = total_pe
        data["pcr"] = round(total_pe / total_ce, 3) if total_ce else None
    return data


@app.get("/autotrade/strategy")
async def at_strategy():
    row = await db.fetchrow("SELECT * FROM strategies WHERE is_active = TRUE LIMIT 1")
    return _row(row) or {}


@app.get("/autotrade/decisions")
async def at_decisions(limit: int = 50):
    rows = await db.fetch(
        """SELECT bd.*, s.name AS strategy_name
             FROM bot_decisions bd
             LEFT JOIN strategies s ON s.id = bd.strategy_id
            ORDER BY bd.time DESC
            LIMIT $1""",
        limit
    )
    return [_row(r) for r in rows]


@app.get("/autotrade/live-decision")
async def at_live_decision():
    """Return the most recent persisted strategy decision."""
    d = await strategy_engine.get_latest_decision()
    return _row(d) or {}


# ── Paper trading endpoints ───────────────────────────────────────────────────

# Lot sizes per underlying (as of 2024 contract specs)
_LOT_SIZES = {
    "nifty50":   75,
    "banknifty": 30,
    "finnifty":  40,
    "midcap":    75,
    "sensex":    20,
}


class PaperOrderRequest(BaseModel):
    symbol: str           # e.g. "nifty50"
    strike: int | None = None   # None for index trades
    opttype: str | None = None  # CE / PE / None
    action: str           # BUY / SELL
    qty: int = 1          # number of lots
    price: float | None = None  # auto from live LTP if omitted
    sl_price: float | None = None
    target_price: float | None = None
    notes: str | None = None


def _get_live_ltp(symbol: str, strike: int | None, opttype: str | None) -> float | None:
    """Resolve current LTP from in-memory live data."""
    if strike and opttype:
        chain = _oc_live.get(symbol, {})
        # _oc_live keys may be int, float, or string — try all variants
        for key in (strike, float(strike), str(strike), str(float(strike))):
            opt = chain.get(key, {}).get(opttype.upper())
            if opt and opt.get("ltp"):
                return float(opt["ltp"])
        return None
    return latest.get(symbol, {}).get("ltp")


@app.post("/paper-trade/order")
async def pt_place_order(req: PaperOrderRequest):
    """Place a paper trade. Price is auto-filled from live data if not provided."""
    sym = req.symbol.lower()
    action = req.action.upper()
    if action not in ("BUY", "SELL"):
        raise HTTPException(400, "action must be BUY or SELL")

    price = req.price
    if price is None:
        price = _get_live_ltp(sym, req.strike, req.opttype)
        if price is None:
            raise HTTPException(400, "No live price available; pass price explicitly")

    lot_size = _LOT_SIZES.get(sym, 1)
    row = await db.fetchrow(
        """INSERT INTO paper_trades
               (symbol, strike, opttype, action, qty, lot_size, price,
                sl_price, target_price, notes)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
           RETURNING *""",
        sym, req.strike, req.opttype, action, req.qty, lot_size,
        price, req.sl_price, req.target_price, req.notes,
    )
    return _row(row)


@app.get("/paper-trade/orders")
async def pt_list_orders(limit: int = 100, status: str = ""):
    if status:
        rows = await db.fetch(
            "SELECT * FROM paper_trades WHERE status=$1 ORDER BY time DESC LIMIT $2",
            status.upper(), limit,
        )
    else:
        rows = await db.fetch(
            "SELECT * FROM paper_trades ORDER BY time DESC LIMIT $1", limit
        )
    return [_row(r) for r in rows]


@app.get("/paper-trade/positions")
async def pt_positions():
    """Open positions with unrealized PnL from current live prices."""
    rows = await db.fetch(
        "SELECT * FROM paper_trades WHERE status='OPEN' ORDER BY time DESC"
    )
    result = []
    for r in rows:
        trade = _row(r)
        sym = trade["symbol"]
        strike = trade.get("strike")
        opttype = trade.get("opttype")
        ltp = _get_live_ltp(sym, strike, opttype)
        entry = float(trade["price"])
        lot_size = trade.get("lot_size") or _LOT_SIZES.get(sym, 1)
        qty = trade.get("qty", 1)
        if ltp:
            multiplier = 1 if trade["action"] == "BUY" else -1
            unrealized_pnl = round(multiplier * (ltp - entry) * lot_size * qty, 2)
            trade["ltp"] = ltp
            trade["unrealized_pnl"] = unrealized_pnl
        else:
            trade["ltp"] = None
            trade["unrealized_pnl"] = None
        result.append(trade)
    return result


@app.post("/paper-trade/close/{trade_id}")
async def pt_close_order(trade_id: int, price: float | None = None):
    """Close an open paper trade. Price defaults to current live LTP."""
    row = await db.fetchrow(
        "SELECT * FROM paper_trades WHERE id=$1", trade_id
    )
    if not row:
        raise HTTPException(404, "Trade not found")
    trade = _row(row)
    if trade["status"] != "OPEN":
        raise HTTPException(400, f"Trade is already {trade['status']}")

    sym = trade["symbol"]
    exit_price = price or _get_live_ltp(sym, trade.get("strike"), trade.get("opttype"))
    if exit_price is None:
        raise HTTPException(400, "No live price available; pass price as query param")

    entry = float(trade["price"])
    lot_size = trade.get("lot_size") or _LOT_SIZES.get(sym, 1)
    qty = trade.get("qty", 1)
    multiplier = 1 if trade["action"] == "BUY" else -1
    pnl = round(multiplier * (exit_price - entry) * lot_size * qty, 2)

    updated = await db.fetchrow(
        """UPDATE paper_trades
           SET status='CLOSED', exit_price=$1, exit_time=NOW(), pnl=$2
           WHERE id=$3 RETURNING *""",
        exit_price, pnl, trade_id,
    )
    return _row(updated)


@app.delete("/paper-trade/orders")
async def pt_delete_all():
    """Delete all paper trades."""
    deleted = await db.fetchval("SELECT COUNT(*) FROM paper_trades")
    await db.execute("DELETE FROM paper_trades")
    return {"deleted": deleted or 0}


@app.get("/paper-trade/summary")
async def pt_summary():
    """Aggregate PnL summary across all closed trades."""
    rows = await db.fetch(
        "SELECT * FROM paper_trades WHERE status='CLOSED' ORDER BY exit_time DESC"
    )
    trades = [_row(r) for r in rows]
    total_pnl = sum(t.get("pnl") or 0 for t in trades)
    wins  = [t for t in trades if (t.get("pnl") or 0) > 0]
    losses= [t for t in trades if (t.get("pnl") or 0) < 0]
    return {
        "total_trades": len(trades),
        "open_trades":  await db.fetchval("SELECT COUNT(*) FROM paper_trades WHERE status='OPEN'"),
        "total_pnl":    round(total_pnl, 2),
        "win_count":    len(wins),
        "loss_count":   len(losses),
        "win_rate_pct": round(len(wins) / len(trades) * 100, 1) if trades else 0,
        "avg_win":      round(sum(t["pnl"] for t in wins)   / len(wins),   2) if wins   else 0,
        "avg_loss":     round(sum(t["pnl"] for t in losses) / len(losses), 2) if losses else 0,
    }


# ── WebSocket endpoints ───────────────────────────────────────────────────────
@app.websocket("/ws/all")
async def ws_all(ws: WebSocket):
    await manager.connect("all", ws)
    try:
        if latest:
            await ws.send_json({"type": "snapshot", "data": latest})
        while True:
            await ws.receive_text()
    except (WebSocketDisconnect, Exception):
        manager.disconnect("all", ws)


# Must be declared BEFORE /ws/{index} so the literal segment "optionchain" wins
@app.websocket("/ws/optionchain/{symbol}")
async def ws_optionchain(ws: WebSocket, symbol: str):
    await oc_manager.connect(symbol, ws)
    try:
        if symbol in _oc_live:
            await ws.send_json({"type": "snapshot", "data": _oc_live[symbol]})
        while True:
            await ws.receive_text()
    except (WebSocketDisconnect, Exception):
        oc_manager.disconnect(symbol, ws)


@app.websocket("/ws/{index}")
async def ws_index(ws: WebSocket, index: str):
    if index not in INDICES:
        await ws.accept()
        await ws.send_json({"error": f"Unknown index '{index}'"})
        await ws.close()
        return
    await manager.connect(index, ws)
    try:
        if index in latest:
            await ws.send_json({"type": "snapshot", "data": latest[index]})
        while True:
            await ws.receive_text()
    except (WebSocketDisconnect, Exception):
        manager.disconnect(index, ws)


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
