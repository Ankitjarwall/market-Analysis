"""
Strategy engine — evaluates the active strategy against the current market snapshot
and writes a row to bot_decisions.

For v1 the engine is read-only: it does NOT place orders — only logs what it
*would* do, including the recommended strike (via all 3 selection methods).
"""
import json
import asyncio
from datetime import datetime, timezone, timedelta

import db
import greeks as greeks_mod

IST = timezone(timedelta(hours=5, minutes=30))

SUPPORTED_OPS = {">", "<", ">=", "<=", "==", "!="}


def _cmp(op: str, a, b) -> bool:
    try:
        a = float(a); b = float(b)
    except Exception:
        a, b = str(a), str(b)
    if op == ">":  return a >  b
    if op == "<":  return a <  b
    if op == ">=": return a >= b
    if op == "<=": return a <= b
    if op == "==": return a == b
    if op == "!=": return a != b
    return False


def _parse_inline_cond(s: str):
    """'>=1' → ('>=', 1). 'BULLISH' → ('==', 'BULLISH')."""
    if not isinstance(s, str):
        return ("==", s)
    s = s.strip()
    for op in (">=", "<=", "==", "!=", ">", "<"):
        if s.startswith(op):
            rest = s[len(op):].strip()
            try:
                return (op, float(rest))
            except Exception:
                return (op, rest)
    return ("==", s)


async def _current_snapshot(symbol: str = "nifty50") -> dict:
    """Latest indicators + signals + options + fii/dii."""
    snap = {"symbol": symbol}

    # Latest 1m candle (indicators)
    candle = await db.fetchrow(
        """SELECT * FROM candles_1m
            WHERE symbol = $1
            ORDER BY time DESC LIMIT 1""",
        symbol
    )
    if candle:
        snap["candle"] = {k: (float(v) if isinstance(v, (int, float)) or hasattr(v, "__float__") else v)
                          for k, v in dict(candle).items() if k not in ("time", "symbol", "token")}

    # Latest global signals
    gs = await db.fetchrow("SELECT * FROM global_signals ORDER BY time DESC LIMIT 1")
    if gs:
        snap["global"] = dict(gs)

    # Latest FII/DII
    fd = await db.fetchrow("SELECT * FROM fii_dii_daily ORDER BY date DESC LIMIT 1")
    if fd:
        snap["fii_dii"] = dict(fd)

    return snap


def _lookup(snap: dict, field: str):
    """Case-insensitive lookup across all snapshot sub-dicts."""
    candle = snap.get("candle") or {}
    glob   = snap.get("global") or {}
    fd     = snap.get("fii_dii") or {}

    for d in (candle, glob, fd):
        if field in d:
            return d[field]
        # case-insensitive fallback
        for k in d.keys():
            if k.lower() == field.lower():
                return d[k]
    return None


def _evaluate_rule_block(block: dict, snap: dict) -> tuple[bool, list]:
    """Returns (matched, list of {cond, result, left, right} entries)."""
    if not block:
        return True, []
    conditions = block.get("conditions", [])
    logic      = (block.get("logic") or "AND").upper()

    results = []
    passed  = []
    for cond in conditions:
        field = cond.get("field")
        op    = cond.get("op", "==")
        left  = _lookup(snap, field)
        if "field2" in cond:
            right = _lookup(snap, cond["field2"])
        else:
            right = cond.get("value")
        ok = False
        if left is not None and right is not None and op in SUPPORTED_OPS:
            ok = _cmp(op, left, right)
        results.append({"cond": cond, "left": left, "right": right, "ok": ok})
        passed.append(ok)

    if logic == "OR":
        matched = any(passed)
    else:
        matched = all(passed) if passed else False
    return matched, results


def _evaluate_bias(criteria: dict, snap: dict) -> tuple[bool, list]:
    """Each bias criterion: {field: 'op value' string}."""
    if not criteria:
        return True, []
    results = []
    passed  = []
    for field, val in criteria.items():
        op, target = _parse_inline_cond(val)
        left = _lookup(snap, field)
        ok = False
        if left is not None:
            ok = _cmp(op, left, target)
        results.append({"field": field, "op": op, "left": left, "right": target, "ok": ok})
        passed.append(ok)
    return all(passed) if passed else True, results


# ── Main entry point (called every minute by scheduler) ───────────────────
# Import latest and OC data from main module at call time to avoid circular imports
def _get_live_data():
    try:
        from main import latest, _oc_live, OC_SYMBOLS
        return latest, _oc_live, OC_SYMBOLS
    except Exception:
        return {}, {}, {}


def _compute_chain_greeks(spot, chain: dict, T: float, r: float) -> list[dict]:
    """Given _oc_live[symbol] chain dict, compute Greeks for each strike/opttype."""
    results = []
    for strike, opts in chain.items():
        for opttype in ("CE", "PE"):
            opt = opts.get(opttype)
            if not opt or not opt.get("ltp"):
                continue
            ltp = float(opt["ltp"])
            is_call = opttype == "CE"
            g = greeks_mod.greeks_from_market(spot, float(strike), T, r, ltp, is_call)
            results.append({
                "strike": strike, "opttype": opttype, "ltp": ltp,
                "oi": opt.get("oi", 0),
                **g,
            })
    return results


async def evaluate_once(symbol: str = "nifty50"):
    try:
        strat = await db.fetchrow(
            "SELECT * FROM strategies WHERE is_active = TRUE LIMIT 1"
        )
        if not strat:
            print("[strategy] no active strategy found — skipping")
            return

        # Use target_symbol from risk_rules if available
        risk_rules = strat["risk_rules"] if isinstance(strat["risk_rules"], dict) \
                     else json.loads(strat["risk_rules"] or "{}")
        target_sym = risk_rules.get("target_symbol", symbol)

        snap = await _current_snapshot(target_sym)
        if "candle" not in snap:
            # Check how many candles exist
            cnt = await db.fetchval("SELECT COUNT(*) FROM candles_1m WHERE symbol=$1", target_sym)
            print(f"[strategy] no candle for {target_sym} in snapshot (DB has {cnt} candles) — waiting for data")
            return

        entry_rules = strat["entry_rules"] if isinstance(strat["entry_rules"], dict) \
                      else json.loads(strat["entry_rules"] or "{}")
        exit_rules  = strat["exit_rules"]  if isinstance(strat["exit_rules"], dict) \
                      else json.loads(strat["exit_rules"]  or "{}")
        bias_criteria = strat["bias_criteria"] if isinstance(strat["bias_criteria"], dict) \
                        else json.loads(strat["bias_criteria"] or "{}")

        entry_ok,  entry_res = _evaluate_rule_block(entry_rules, snap)
        exit_ok,   exit_res  = _evaluate_rule_block(exit_rules,  snap)
        bias_ok,   bias_res  = _evaluate_bias(bias_criteria, snap)

        if exit_ok:
            decision = "EXIT"
        elif entry_ok and bias_ok:
            decision = "ENTRY_BUY"
        elif entry_ok and not bias_ok:
            decision = "NEUTRAL"   # signal but bias disagrees
        else:
            decision = "NEUTRAL"

        matched = {
            "entry": {"passed": entry_ok, "details": entry_res},
            "exit":  {"passed": exit_ok,  "details": exit_res},
            "bias":  {"passed": bias_ok,  "details": bias_res},
        }

        # ── Strike recommendation (only when decision is ENTRY_BUY) ─────────
        strike_rec = None
        latest, _oc_live, OC_SYMBOLS = _get_live_data()
        spot = latest.get(target_sym, {}).get("ltp", 0)
        chain = _oc_live.get(target_sym, {})
        oc_cfg = OC_SYMBOLS.get(target_sym, {})
        step = oc_cfg.get("step", 50)

        if decision.startswith("ENTRY") and spot and chain:
            is_call = decision == "ENTRY_BUY"
            opt_sel = risk_rules.get("option_selection", {})
            T = 5.0 / 365.0   # default ~5 days to expiry; TODO: compute from actual expiry
            r = greeks_mod.RISK_FREE_RATE

            # Compute Greeks for the full chain
            chain_greeks = _compute_chain_greeks(spot, chain, T, r)

            # Find ATM IV for skew method
            atm_strike = round(spot / step) * step
            atm_iv = None
            for cg in chain_greeks:
                if cg["strike"] == atm_strike and cg["opttype"] == ("CE" if is_call else "PE"):
                    atm_iv = cg.get("iv")
                    if atm_iv:
                        atm_iv = atm_iv / 100.0  # convert % to decimal
                    break

            # All 3 methods
            method_a_strike = greeks_mod.pick_strike_fixed_offset(spot, step,
                                opt_sel.get("offset_strikes", 1), is_call)

            method_b = greeks_mod.pick_strike_by_delta(spot, chain_greeks,
                         opt_sel.get("target_delta", 0.3), is_call)

            method_c = greeks_mod.pick_strike_by_iv_skew(spot, chain_greeks,
                         atm_iv, is_call)

            strike_rec = {
                "is_call": is_call,
                "spot": spot,
                "atm_strike": atm_strike,
                "method_fixed_offset": {"strike": method_a_strike},
                "method_delta": {
                    "strike": method_b["strike"] if method_b else None,
                    "delta":  method_b["delta"]  if method_b else None,
                    "ltp":    method_b["ltp"]    if method_b else None,
                },
                "method_iv_skew": {
                    "strike":  method_c["strike"] if method_c else None,
                    "iv":      method_c["iv"]     if method_c else None,
                    "ltp":     method_c["ltp"]    if method_c else None,
                },
                "preferred_method": opt_sel.get("method", "delta"),
            }

        snap["strike_recommendation"] = strike_rec

        await db.execute(
            """INSERT INTO bot_decisions
               (time, strategy_id, symbol, decision, matched_rules, market_snapshot, notes)
               VALUES ($1, $2, $3, $4, $5::jsonb, $6::jsonb, NULL)""",
            datetime.now(timezone.utc),
            strat["id"], target_sym, decision,
            json.dumps(matched, default=str),
            json.dumps(snap,    default=str),
        )
        print(f"[strategy] decision={decision} symbol={target_sym} entry={entry_ok} exit={exit_ok} bias={bias_ok}")

    except Exception as e:
        import traceback
        print(f"[strategy] evaluate_once error: {e}")
        traceback.print_exc()


async def get_latest_decision():
    row = await db.fetchrow(
        """SELECT bd.*, s.name as strategy_name
             FROM bot_decisions bd
             LEFT JOIN strategies s ON s.id = bd.strategy_id
            ORDER BY bd.time DESC LIMIT 1"""
    )
    return dict(row) if row else None
