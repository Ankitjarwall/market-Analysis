"""
Batched tick persistence + minute-candle aggregator.

Two background tasks:
  1. tick_flusher         — flushes raw_ticks / option_ticks every 500 ms
  2. minute_aggregator    — at every minute boundary, builds 1-minute candles
                            from accumulated ticks, computes indicators, writes
                            candles_1m and option_candles_1m.
"""
import asyncio
import time
from datetime import datetime, timezone, timedelta
from typing import Any
import pandas as pd

import db
from indicators import compute_indicators, INDICATOR_COLS
import greeks as greeks_mod

# ── Buffers populated from the main tick pump ────────────────────────────────
_idx_tick_buf:   list[tuple] = []   # raw_ticks rows
_opt_tick_buf:   list[tuple] = []   # option_ticks rows

# Accumulated ticks for the current minute, used by the aggregator
_idx_minute: dict[str, list[dict]] = {}    # symbol → list of ticks this minute
_opt_minute: dict[str, list[dict]] = {}    # token  → list of ticks this minute

_lock = asyncio.Lock()


# ────────────────────────────────────────────────────────────────────────────
#  PUBLIC: called from _process_ticks() in main.py
# ────────────────────────────────────────────────────────────────────────────
async def push_index_tick(symbol: str, token: str, tick: dict):
    """tick = dict from _parse_tick (ltp, open, high, low, close, volume, ts)."""
    now = datetime.now(timezone.utc)
    row = (
        now,
        symbol,
        token,
        tick.get("ltp"),
        tick.get("open"),
        tick.get("high"),
        tick.get("low"),
        tick.get("close"),
        tick.get("volume"),
        None,  # exchange_ts — best left null if Angel One sends epoch
    )
    async with _lock:
        _idx_tick_buf.append(row)
        _idx_minute.setdefault(symbol, []).append({
            "t": now, "o": tick.get("ltp"), "h": tick.get("ltp"),
            "l": tick.get("ltp"), "c": tick.get("ltp"),
            "v": tick.get("volume") or 0, "token": token,
        })


async def push_option_tick(symbol: str, expiry: str, strike: int, opttype: str,
                           token: str, tick: dict):
    """tick = dict with ltp, oi, volume, change, changePct."""
    now = datetime.now(timezone.utc)
    try:
        exp_d = datetime.strptime(expiry, "%d%b%Y").date()
    except Exception:
        try:
            exp_d = datetime.strptime(expiry, "%d%b%y").date()
        except Exception:
            exp_d = None
    if exp_d is None:
        return
    # Compute Greeks from spot price (imported from main at call time)
    ltp_val = tick.get("ltp")
    g_iv = g_delta = g_gamma = g_theta = g_vega = None
    if ltp_val and ltp_val > 0:
        try:
            from main import latest
            spot = latest.get(symbol, {}).get("ltp", 0)
            if spot and spot > 0 and exp_d:
                days_to_exp = max(0.25, (exp_d - now.date()).days + 0.5)
                T = days_to_exp / 365.0
                r = greeks_mod.RISK_FREE_RATE
                is_call = opttype == "CE"
                g = greeks_mod.greeks_from_market(spot, float(strike), T, r, float(ltp_val), is_call)
                g_iv    = g.get("iv")
                g_delta = g.get("delta")
                g_gamma = g.get("gamma")
                g_theta = g.get("theta")
                g_vega  = g.get("vega")
        except Exception:
            pass

    row = (
        now, symbol, exp_d, strike, opttype, token,
        ltp_val, tick.get("oi"), tick.get("volume"),
        tick.get("change"), tick.get("changePct"),
        g_iv, g_delta, g_gamma, g_theta, g_vega,
    )
    async with _lock:
        _opt_tick_buf.append(row)
        _opt_minute.setdefault(token, []).append({
            "t": now, "o": tick.get("ltp"), "h": tick.get("ltp"),
            "l": tick.get("ltp"), "c": tick.get("ltp"),
            "v": tick.get("volume") or 0, "oi": tick.get("oi") or 0,
            "symbol": symbol, "expiry": exp_d, "strike": strike, "opttype": opttype,
        })


# ────────────────────────────────────────────────────────────────────────────
#  BACKGROUND: flush the tick buffers every 500 ms
# ────────────────────────────────────────────────────────────────────────────
async def tick_flusher():
    print("[ticks] flusher started")
    while True:
        await asyncio.sleep(0.5)
        try:
            async with _lock:
                idx_batch = _idx_tick_buf[:]
                opt_batch = _opt_tick_buf[:]
                _idx_tick_buf.clear()
                _opt_tick_buf.clear()

            if idx_batch:
                await db.copy_records(
                    "raw_ticks",
                    idx_batch,
                    ["time", "symbol", "token", "ltp", "open", "high",
                     "low", "close", "volume", "exchange_ts"],
                )
            if opt_batch:
                await db.copy_records(
                    "option_ticks",
                    opt_batch,
                    ["time", "symbol", "expiry", "strike", "opttype", "token",
                     "ltp", "oi", "volume", "chg", "chg_pct",
                     "iv", "delta", "gamma", "theta", "vega"],
                )
        except Exception as e:
            print(f"[ticks] flush error: {e}")


# ────────────────────────────────────────────────────────────────────────────
#  BACKGROUND: minute aggregator
#    Wakes up at each minute boundary, rolls the previous minute of ticks into
#    a single candle, computes indicators using the last 100 candles from DB,
#    and inserts into candles_1m (plus option_candles_1m).
# ────────────────────────────────────────────────────────────────────────────
async def minute_aggregator():
    print("[candles] aggregator started")
    # Wait until the next minute boundary
    await _sleep_until_next_minute()
    while True:
        minute_start = datetime.now(timezone.utc).replace(second=0, microsecond=0) - timedelta(minutes=1)
        minute_end   = minute_start + timedelta(minutes=1)
        try:
            await _roll_index_minute(minute_start, minute_end)
            await _roll_option_minute(minute_start, minute_end)
        except Exception as e:
            print(f"[candles] aggregator error: {e}")
        await _sleep_until_next_minute()


async def _sleep_until_next_minute():
    now = datetime.now(timezone.utc)
    next_m = (now + timedelta(minutes=1)).replace(second=1, microsecond=0)
    await asyncio.sleep(max(0.5, (next_m - now).total_seconds()))


async def _roll_index_minute(start: datetime, end: datetime):
    """Aggregate the previous minute of index ticks into candles_1m rows."""
    async with _lock:
        symbols = list(_idx_minute.keys())
        minute_data = {s: _idx_minute.pop(s) for s in symbols}

    for symbol, ticks in minute_data.items():
        if not ticks:
            continue
        # Only ticks within [start, end)
        in_window = [x for x in ticks if start <= x["t"] < end]
        if not in_window:
            continue
        o = in_window[0]["o"]
        h = max(x["h"] for x in in_window)
        l = min(x["l"] for x in in_window)
        c = in_window[-1]["c"]
        v = in_window[-1]["v"]  # Angel One sends cumulative volume — take last
        token = in_window[-1]["token"]

        # Pull last 100 candles from DB for indicator context
        try:
            rows = await db.fetch(
                """SELECT time, open, high, low, close, volume
                     FROM candles_1m
                    WHERE symbol = $1 AND time < $2
                    ORDER BY time DESC
                    LIMIT 100""",
                symbol, start
            )
            hist = list(reversed([dict(r) for r in rows]))
            hist.append({"time": start, "open": o, "high": h, "low": l, "close": c, "volume": v})
            df = pd.DataFrame(hist).set_index("time")
            df = compute_indicators(df)
            last = df.iloc[-1]

            vals = {}
            for col in INDICATOR_COLS:
                v_ = last.get(col)
                if pd.isna(v_):
                    vals[col] = None
                elif col in ("obv", "supertrend_dir"):
                    vals[col] = int(v_)
                else:
                    vals[col] = float(v_)

            await db.execute(
                """INSERT INTO candles_1m
                   (time, symbol, token, open, high, low, close, volume,
                    rsi, macd, macd_signal, macd_hist,
                    ema_9, ema_21, ema_50, vwap, adx, atr,
                    bb_upper, bb_middle, bb_lower,
                    supertrend, supertrend_dir, obv)
                   VALUES ($1,$2,$3,$4,$5,$6,$7,$8,
                           $9,$10,$11,$12,
                           $13,$14,$15,$16,$17,$18,
                           $19,$20,$21,
                           $22,$23,$24)
                   ON CONFLICT (time, symbol) DO NOTHING""",
                start, symbol, token, o, h, l, c, v,
                vals["rsi"], vals["macd"], vals["macd_signal"], vals["macd_hist"],
                vals["ema_9"], vals["ema_21"], vals["ema_50"], vals["vwap"],
                vals["adx"], vals["atr"],
                vals["bb_upper"], vals["bb_middle"], vals["bb_lower"],
                vals["supertrend"], vals["supertrend_dir"], vals["obv"],
            )
        except Exception as e:
            print(f"[candles] {symbol} {start} insert failed: {e}")


async def _roll_option_minute(start: datetime, end: datetime):
    """Aggregate option ticks to option_candles_1m rows."""
    async with _lock:
        tokens = list(_opt_minute.keys())
        tok_data = {t: _opt_minute.pop(t) for t in tokens}

    rows = []
    for token, ticks in tok_data.items():
        in_window = [x for x in ticks if start <= x["t"] < end]
        if not in_window:
            continue
        first = in_window[0]
        o = first["o"]
        h = max(x["h"] for x in in_window)
        l = min(x["l"] for x in in_window)
        c = in_window[-1]["c"]
        v = in_window[-1]["v"]
        oi = in_window[-1]["oi"]
        # Compute Greeks for the close price
        g_iv = g_delta = g_gamma = g_theta = g_vega = None
        try:
            from main import latest
            spot = latest.get(first["symbol"], {}).get("ltp", 0)
            exp_d = first["expiry"]
            if spot and spot > 0 and c and c > 0 and exp_d:
                days_to_exp = max(0.25, (exp_d - start.date()).days + 0.5)
                T = days_to_exp / 365.0
                r = greeks_mod.RISK_FREE_RATE
                is_call = first["opttype"] == "CE"
                g = greeks_mod.greeks_from_market(spot, float(first["strike"]), T, r, float(c), is_call)
                g_iv    = g.get("iv")
                g_delta = g.get("delta")
                g_gamma = g.get("gamma")
                g_theta = g.get("theta")
                g_vega  = g.get("vega")
        except Exception:
            pass

        rows.append((
            start, first["symbol"], first["expiry"], first["strike"], first["opttype"], token,
            o, h, l, c, v, oi,
            g_iv, g_delta, g_gamma, g_theta, g_vega,
        ))

    if rows:
        try:
            await db.copy_records(
                "option_candles_1m",
                rows,
                ["time","symbol","expiry","strike","opttype","token",
                 "open","high","low","close","volume","oi",
                 "iv","delta","gamma","theta","vega"],
            )
        except Exception as e:
            print(f"[candles] option insert failed: {e}")
